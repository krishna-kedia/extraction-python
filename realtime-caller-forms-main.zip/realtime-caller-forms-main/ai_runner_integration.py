import subprocess
import sys
import re
import threading
import time
import signal
import os
import queue
import locale
from typing import List, Dict, Any, Optional

# Import our OpenAI handler
from openai_api_handler import OpenAIHandler

sys.stdout.reconfigure(encoding='utf-8')  # Python 3.7+

class AIRunner:
    """
    AI Runner - Manages interaction between CLI applications and AI
    Sends CLI output to AI and passes AI responses back to CLI
    """

    def __init__(self, api_key: Optional[str] = None, model_name: str = "gpt-4o-mini", system_task: str = "", batch_mode: bool = False, enable_functions=False, whatsapp_number: Optional[str] = None):
        self.process = None
        self.buffer = []
        self.waiting_for_input = False
        self.current_prompt = ""
        self.current_input_type = "text"
        self.available_options = None
        self.is_running = False
        self.current_app = None
        self.conversation_history = []
        self.auto_mode = False
        self.always_show_ai_suggestion = False
        self.batch_mode = batch_mode  # Store batch_mode flag
        self.whatsapp_number = whatsapp_number  # Store the WhatsApp number

        print(
            f"\033[36mAIRunner initialized with enable_functions={enable_functions}\033[0m")

        self.enable_functions = enable_functions

        # Store system task for AI
        self.system_task = system_task or """
        Your task is to help the user navigate and use this CLI application effectively.
        Try to understand what the user is trying to accomplish and provide appropriate inputs.
        """
        # Log before initializing the OpenAI handler
        print(
            f"\033[36mInitializing OpenAIHandler with enable_functions={self.enable_functions}\033[0m")

        # Initialize OpenAI handler
        self.ai_handler = OpenAIHandler(
            api_key=api_key,
            model_name=model_name,
            enable_functions=self.enable_functions,
            whatsapp_number=whatsapp_number  # Pass the WhatsApp number
        )

        # Add output queue to prevent deadlocks
        self.stdout_queue = queue.Queue()
        self.stderr_queue = queue.Queue()

        # Get system encoding
        self.system_encoding = locale.getpreferredencoding() or 'utf-8'
        print(f"System encoding detected: {self.system_encoding}")

    def start(self, app_type: str) -> None:
        """Start a CLI application"""
        self.is_running = True
        self.current_app = app_type

        # Clear AI handler history when starting a new app
        self.ai_handler.clear_history()

        print(f"Starting {app_type} CLI with AI integration...")

        # Configure the command based on app type
        if app_type == "whatsapp":
            command = ["node", "whatsapp-cli.js", "--api-mode"]
        elif app_type == "form":
            command = [sys.executable, "-u", "form.py", "--api-mode"]
        elif app_type == "travel":
            # Use the Python interpreter from the virtual environment
            venv_python = os.path.join(os.path.dirname(sys.executable), "python.exe")
            command = [venv_python, "-u", "travel.py", "--api-mode"]
        else:
            print("Unknown app type")
            return self.prompt_for_app_type()

        try:
            # Use text mode, utf-8 encoding, and line buffering
            # Set PYTHONIOENCODING for the child process as well for robustness
            child_env = os.environ.copy()
            child_env["PYTHONIOENCODING"] = "utf-8"

            self.process = subprocess.Popen(
                command,
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,                 # Use text mode
                encoding='utf-8',          # Specify encoding
                bufsize=1,                 # Line buffering
                # startupinfo=startupinfo, # Comment out for debugging
                env=child_env              # Pass environment with encoding hint
            )

            # Start threads to read stdout and stderr and put into queues
            stdout_thread = threading.Thread(
                target=self.read_pipe_lines, args=(self.process.stdout, self.stdout_queue))
            stderr_thread = threading.Thread(
                target=self.read_pipe_lines, args=(self.process.stderr, self.stderr_queue))

            # Start thread to process queued output
            process_thread = threading.Thread(
                target=self.process_queued_output)

            # Set daemon to ensure threads terminate when main program ends
            stdout_thread.daemon = True
            stderr_thread.daemon = True
            process_thread.daemon = True

            stdout_thread.start()
            stderr_thread.start()
            process_thread.start()

            # Wait for process to complete
            self.process.wait()

            print(
                f"{app_type} CLI process exited with code {self.process.returncode}")
            self.is_running = False
            if self.batch_mode:
                print("Batch mode enabled, exiting...")
                sys.exit(0)  # Exit when in batch mode
            else:
                self.prompt_for_app_type()  # Otherwise prompt for next app

        except Exception as e:
            print(f"Error starting {app_type} CLI: {str(e)}")
            self.is_running = False
            self.prompt_for_app_type()

    # Rename queue_output for clarity and modify its logic
    def read_pipe_lines(self, pipe, output_queue):
        """Read lines from text pipe and put into queue"""
        try:
            # Read line by line from the text stream
            # iter(pipe.readline, '') ensures it stops on EOF
            for line in iter(pipe.readline, ''):
                if not self.is_running:  # Check if we should stop early
                    break
                # print(f"DEBUG: Received line: {line.strip()}") # Add temporary debug
                # Put the full line (string) in the queue
                output_queue.put(line)
        except ValueError:
            # This can happen if the pipe is closed unexpectedly
            print(f"Pipe closed or ValueError during readline.")
        except Exception as e:
            # Log other potential errors during reading
            print(f"Error reading lines from pipe: {str(e)}", flush=True)
        finally:
            # Ensure None is put even if loop breaks early or errors occur
            output_queue.put(None)  # Signal end of stream for this pipe
            print(f"Finished reading from pipe {pipe}")


    def process_queued_output(self):
        """Process output lines from the queues"""
        stdout_finished = False
        stderr_finished = False

        while not (stdout_finished and stderr_finished):
            processed_something = False

            # Process stdout
            if not stdout_finished:
                try:
                    # Use a short timeout to prevent blocking indefinitely if
                    # one stream finishes long before the other.
                    line = self.stdout_queue.get(block=True, timeout=0.05)
                    if line is None:
                        stdout_finished = True
                        # print("DEBUG: stdout stream finished") # Debug
                    else:
                        # Line is already a decoded string, strip trailing newline/whitespace
                        line_stripped = line.rstrip()

                        # Immediately process error status messages rather than buffering them
                        if line_stripped.startswith("<STATUS:ERROR"):
                            error_match = re.search(
                                r'message="([^"]+)"', line_stripped)
                            error_message = error_match.group(
                                1) if error_match else "Unknown error"

                            try:
                                print(f"\033[91mError: {line.rstrip()}\033[0m", flush=True)
                            except UnicodeEncodeError:
                                # Fall back to ASCII encoding with replacement characters
                                print(
                                    f"\033[91mError: {line.rstrip().encode('ascii', 'replace').decode('ascii')}\033[0m", flush=True)

                        else:
                            self.process_output_line(line_stripped)

                        processed_something = True
                except queue.Empty:
                    pass  # No stdout data currently available
                except Exception as e:  # Catch potential errors during processing
                    print(
                        f"Error processing stdout line: {str(e)}", flush=True)
                    stdout_finished = True  # Treat error as end of stream

            # Process stderr
            if not stderr_finished:
                try:
                    line = self.stderr_queue.get(block=True, timeout=0.05)
                    if line is None:
                        stderr_finished = True
                        # print("DEBUG: stderr stream finished") # Debug
                    else:
                        # Already a string, strip trailing newline/whitespace
                        # Ensure error messages always appear
                        print(
                            f"\033[91mError: {line.rstrip()}\033[0m", flush=True)
                        processed_something = True
                except queue.Empty:
                    pass  # No stderr data currently available
                except Exception as e:  # Catch potential errors during processing
                    print(
                        f"\033[91mError: {line.rstrip()}\033[0m", flush=True)
                    stderr_finished = True  # Treat error as end of stream
                
    def process_output_line(self, line: str) -> None:
        """Process a single line of output"""
        # print(f"DEBUG: Processing line: {line}")

        if line == "<OUTPUT_COMPLETE>":
            # End of output block reached
            self.display_buffer()

            # Add output to conversation history
            if self.buffer:
                system_output = "\n".join(self.buffer)
                # Add to our local history
                self.conversation_history.append({
                    "role": "system",
                    "content": system_output
                })
                # Add to OpenAI handler history
                self.ai_handler.add_to_history("system", system_output)
                self.buffer = []
                
        elif line.startswith("<INPUT_REQUEST"):
            # --- MODIFICATION START ---
            # Input request detected.
            # FIRST, display any output that was buffered *before* this request.
            self.display_buffer()  # This now prints the buffer contents

            # Add the buffered output (which was just displayed) to history
            # BEFORE the AI sees the prompt context.
            if self.buffer:
                system_output = "\n".join(self.buffer)
                self.conversation_history.append({
                    "role": "system",
                    "content": system_output
                })
                self.ai_handler.add_to_history("system", system_output)
                # Clear the buffer *after* adding to history and displaying
                self.buffer = []
            # --- MODIFICATION END ---

            # Now, proceed with handling the input request itself
            self.waiting_for_input = True

            # Parse the input request
            type_match = re.search(r'type="([^"]+)"', line)
            self.current_input_type = type_match.group(
                1) if type_match else "text"

            prompt_match = re.search(r'prompt="([^"]+)"', line)
            self.current_prompt = prompt_match.group(
                1) if prompt_match else "Enter input:"

            options_match = re.search(r'options="([^"]+)"', line)
            if options_match:
                self.available_options = options_match.group(1).split(",")
            else:
                self.available_options = None

            # If in auto mode, get AI response
            if self.auto_mode:
                self.get_ai_response()
            else:
                # Otherwise prompt user and show AI/manual mode toggle
                self.request_user_input()
        elif line.startswith("<STATUS:ERROR"):
            # --- Also display buffer before error ---
            self.display_buffer()
            if self.buffer:
                system_output = "\n".join(self.buffer)
                self.conversation_history.append(
                    {"role": "system", "content": system_output})
                self.ai_handler.add_to_history("system", system_output)
                self.buffer = []
            # --- End buffer display before error ---

            # Extract error message from status tag
            error_match = re.search(r'message="([^"]+)"', line)
            error_message = error_match.group(
                1) if error_match else "Unknown error"
            print(f"\033[91mError: {error_message}\033[0m", flush=True)  # Red text
            self.ai_handler.add_to_history("system", f"ERROR: {error_message}")

        elif line.startswith("<STATUS:"):
            # Display buffer before status? Maybe less critical.
            self.display_buffer()
            if self.buffer:
                system_output = "\n".join(self.buffer)
                self.conversation_history.append(
                    {"role": "system", "content": system_output})
                self.ai_handler.add_to_history("system", system_output)
                self.buffer = []

            # Status update
            status_match = re.search(r"<STATUS:([^>]+)>", line)
            if status_match:
                status_text = status_match.group(1)
                if status_text.startswith("ERROR"):
                    error_match = re.search(r'message="([^"]+)"', line)
                    error_message = error_match.group(
                        1) if error_match else "Unknown error"
                    # Red text
                    print(f"\033[91mError: {error_message}\033[0m", flush=True)
                else:
                    # Cyan text
                    print(f"\033[36mStatus: {status_text}\033[0m", flush=True)
        elif line.strip():
            # Regular output - add to buffer
            self.buffer.append(line)

    def display_buffer(self) -> None:
        """Display the current buffer contents"""
        if self.buffer:
            output_to_display = "\n".join(self.buffer)
            # The prompt_tester captures stdout, so just print normally.
            # Ensure flush=True for immediate visibility in interactive mode.
            print(output_to_display, flush=True)
            # IMPORTANT: We now clear the buffer *after* calling display_buffer
            # in the process_output_line method, specifically after potentially
            # adding its contents to the history.

    def request_user_input(self) -> None:
        """Request input based on the selected interaction mode"""
        # Display the CLI prompt
        display_prompt = self.current_prompt

        if self.current_input_type == "option" and self.available_options:
            display_prompt += f" [{'/'.join(self.available_options)}]"

        # Show the prompt from the CLI
        print(f"\033[33m{display_prompt}\033[0m")

        # Handle based on mode
        if self.auto_mode:
            # In full auto mode, let AI respond automatically
            self.get_ai_response()
            return

        elif self.always_show_ai_suggestion:
            # In AI suggestion mode, show what AI would respond with
            ai_answer = self.get_ai_suggestion()
            print(f"\033[36mAI suggests: {ai_answer}\033[0m")
            print(
                "\033[32m[1] Use AI suggestion  [2] Enter manual response  [3] Toggle auto mode\033[0m")
            print("\033[33m> \033[0m", end="")

            try:
                choice = input()

                if choice == "1":
                    # Use AI suggestion
                    self.send_to_process(ai_answer)

                    # Add to conversation history (local)
                    self.conversation_history.append({
                        "role": "assistant",
                        "content": ai_answer
                    })
                elif choice == "3":
                    # Toggle auto mode
                    self.auto_mode = not self.auto_mode
                    print(
                        f"\033[36mAI auto-mode is now {'ON' if self.auto_mode else 'OFF'}\033[0m")

                    if self.auto_mode:
                        # If turning on auto-mode, immediately get AI response
                        self.get_ai_response()
                    else:
                        # Try again
                        self.request_user_input()
                else:
                    # Manual input (option 2 or any other input)
                    print("\033[33mEnter your response: \033[0m", end="")
                    manual_answer = input()

                    # Send manual response
                    self.send_to_process(manual_answer)

                    # Add to conversation history (local and OpenAI)
                    self.conversation_history.append({
                        "role": "user",
                        "content": manual_answer
                    })
                    self.ai_handler.add_to_history("user", manual_answer)
            except EOFError:
                self.stop()

        else:
            # Purely manual mode
            print("\033[33m> \033[0m", end="")

            try:
                answer = input()

                # Send to process
                self.send_to_process(answer)

                # Add to conversation history (local and OpenAI)
                self.conversation_history.append({
                    "role": "user",
                    "content": answer
                })
                self.ai_handler.add_to_history("user", answer)

            except EOFError:
                # Handle end of input
                self.stop()

    def get_ai_suggestion(self) -> str:
        """Get a suggested response from AI without sending it"""
        try:
            return self.ai_handler.get_ai_response(
                prompt=self.current_prompt,
                app_context=self.current_app,
                current_input_type=self.current_input_type,
                available_options=self.available_options,
                system_task=self.system_task
            )
        except Exception as e:
            print(f"\033[91mError getting AI suggestion: {str(e)}\033[0m")
            return "Error getting AI response"

    def get_ai_response(self) -> None:
        """Request response from AI and send to process"""
        print("\033[36mGetting AI response...\033[0m")

        try:
            # Get response from AI handler
            ai_answer = self.ai_handler.get_ai_response(
                prompt=self.current_prompt,
                app_context=self.current_app,
                current_input_type=self.current_input_type,
                available_options=self.available_options,
                system_task=self.system_task
            )

            print(f"\033[32mAI response: {ai_answer}\033[0m")

            # Send the AI's answer to the process
            self.send_to_process(ai_answer)

            # Add to local conversation history
            self.conversation_history.append({
                "role": "assistant",
                "content": ai_answer
            })
            # The OpenAI handler has already added this to its history

        except Exception as e:
            print(f"\033[91mError in AI integration: {str(e)}\033[0m")
            # Fall back to manual input
            self.auto_mode = False
            self.request_user_input()


    def send_to_process(self, answer: str) -> None:
        """Send input string to the child process"""
        # Check if answer is needed or just continuation
        if not answer and self.current_input_type == "continuation":
            answer = ""  # Send empty string for continuation

        # Handle multi-line inputs from LLM
        if "\n" in answer:
            lines = answer.strip().split("\n")
            print(
                f"\033[91mWarning: Multi-line input detected. Only the first line will be sent.\033[0m")
            answer = lines[0]  # Only take the first line

        # Add newline, required for readline() in the child
        input_line = answer + "\n"

        print(f"DEBUG: Sending to process (text mode): {repr(input_line)}")

        try:
            if self.process and self.process.poll() is None:
                # Write the string directly (encoding handled by text=True)
                self.process.stdin.write(input_line)
                # Flush is still important!
                self.process.stdin.flush()
                print("Input sent to process")
            else:
                print("Process is not running, cannot send input")
        except Exception as e:
            print(f"Error sending to process: {str(e)}")

        self.waiting_for_input = False  # Reset flag

    def stop(self) -> None:
        """Stop the current CLI application"""
        if self.process and self.process.poll() is None:
            print("Stopping CLI application...")

            try:
                # Try graceful termination first
                self.process.terminate()

                # Give it some time to terminate
                time.sleep(1)

                # If still running, force kill
                if self.process.poll() is None:
                    self.process.kill()
            except Exception as e:
                print(f"Error stopping process: {str(e)}")

            self.process = None

        self.is_running = False
        # Clear conversation history
        self.conversation_history = []
        self.ai_handler.clear_history()

    def prompt_for_app_type(self) -> None:
        """Prompt the user to select an app type and interaction mode"""
        print("\n=== AI CLI Runner ===")
        print("1. WhatsApp CLI")
        print("2. Form CLI")
        print("3. Travel Booking CLI")
        print("4. Exit")

        try:
            answer = input("Select an application to run: ")

            app_type = None
            if answer == "1":
                app_type = "whatsapp"
            elif answer == "2":
                app_type = "form"
            elif answer == "3":
                app_type = "travel"
            elif answer == "4":
                print("Exiting...")
                sys.exit(0)
            else:
                print("Invalid selection")
                self.prompt_for_app_type()
                return

            # Now ask for interaction mode
            print("\n=== Select Interaction Mode ===")
            print("1. Manual mode (you provide all inputs)")
            print("2. AI mode (AI suggests responses for each prompt)")
            print("3. AI auto mode (AI automatically responds to all prompts)")

            mode_answer = input("Select interaction mode: ")

            # Clear history before starting new app
            self.conversation_history = []
            self.ai_handler.clear_history()

            if mode_answer == "1":
                # Manual mode
                self.auto_mode = False
                self.always_show_ai_suggestion = False
                print("\nManual mode selected. You will provide all inputs.")
            elif mode_answer == "2":
                # AI mode for each prompt
                self.auto_mode = False
                print(
                    "\nAI mode selected. AI will suggest responses, but you confirm each one.")
                # We'll handle this in request_user_input by always showing AI response first
                self.always_show_ai_suggestion = True
            elif mode_answer == "3":
                # Full auto mode
                self.auto_mode = True
                self.always_show_ai_suggestion = False
                print(
                    "\nAI auto mode selected. AI will automatically respond to all prompts.")
            else:
                print("Invalid selection, defaulting to manual mode.")
                self.auto_mode = False
                self.always_show_ai_suggestion = False

            # Start the selected application
            self.start(app_type)

        except KeyboardInterrupt:
            print("\nExiting...")
            sys.exit(0)
        except EOFError:
            print("\nExiting...")
            sys.exit(0)


# Create the runner instance
runner = None


def signal_handler(sig, frame):
    """Handle interrupt signal"""
    print("\nShutting down...")
    global runner
    if runner and runner.process and runner.process.poll() is None:
        runner.stop()
    sys.exit(0)


# Register signal handler
signal.signal(signal.SIGINT, signal_handler)

# Create and start the runner
if __name__ == "__main__":
    # Check for API key in environment or command line
    api_key = os.getenv("OPENAI_API_KEY")

    # Get model name from command line if provided
    model_name = "gpt-4o-mini"  # Default model
    if len(sys.argv) > 1:
        model_name = sys.argv[1]

    # Verify API key exists
    if not api_key:
        print(
            "\033[91mWarning: No OpenAI API key found. Please set the OPENAI_API_KEY environment variable.\033[0m")
        print("You can set it with:")
        print("  export OPENAI_API_KEY=your_api_key  # On Linux/Mac")
        print("  set OPENAI_API_KEY=your_api_key     # On Windows CMD")
        print("  $env:OPENAI_API_KEY='your_api_key'  # On Windows PowerShell")

        # Ask if user wants to continue without API key (will use simulated responses)
        print("\nCDo you want to continue without an API key? (y/n)")
        answer = input("> ").lower()
        if answer != 'y':
            print("Exiting...")
            sys.exit(1)

    print(f"Using model: {model_name}")
    runner = AIRunner(api_key=api_key, model_name=model_name)
    runner.prompt_for_app_type()
