import os
import logging
import json
from typing import List, Dict, Any, Optional
from openai import OpenAI
from dotenv import load_dotenv

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    # format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    format='%(message)s'

)
logger = logging.getLogger("openai_api_handler")

# Set httpx logger to a higher level to suppress its logs
httpx_logger = logging.getLogger("httpx")
# or logging.ERROR to be even more restrictive
httpx_logger.setLevel(logging.WARNING)


class OpenAIHandler:
    """
    Handle interactions with OpenAI API, maintaining conversation history
    and processing responses for the AIRunner.
    """

    def __init__(self, api_key: Optional[str] = None, model_name: str = "gpt-4o-mini",
                 enable_functions: bool = False, whatsapp_number: Optional[str] = None):

        """
        Initialize the OpenAI handler with API key and default model
        
        Args:
            api_key: OpenAI API key (defaults to OPENAI_API_KEY environment variable)
            model_name: OpenAI model to use (defaults to gpt-4o-mini)
        """
        # Log the value received by the constructor
        print(
            f"\033[36mOpenAIHandler initialized with enable_functions={enable_functions}\033[0m")

        load_dotenv()
        self.api_key = api_key or os.getenv("OPENAI_API_KEY")
        if not self.api_key:
            logger.warning(
                "No OpenAI API key provided. Set OPENAI_API_KEY environment variable or pass api_key parameter.")

        self.client = OpenAI(api_key=self.api_key)
        self.model_name = model_name
        self.conversation_history = []
        self.max_history_length = 100  # Max number of messages to keep in history
        self.enable_functions = enable_functions
        self.whatsapp_number = whatsapp_number  # Store the WhatsApp number
        self.functions = [
            {
                "type": "function",
                "function": {
                    "name": "get_next_actions",
                    "description": "Call this function when the task is complete or when you need additional information",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "task_update": {
                                "type": "string",
                                "description": "Provide either: 1) Complete detailed results of the task (include all relevant details like hotel names, prices, etc.), 2) A clear request for specific information needed from the user (e.g., 'Please provide your preferred price range'), or 3) Options that require user decision (e.g., 'Please choose one of these room types: Standard ($100), Deluxe ($150), Suite ($250)'). Format the information clearly with line breaks and numbering where appropriate."
                            }
                        },
                        "required": [
                            "task_update"
                        ],
                        "additionalProperties": False
                    },
                    "strict": True
                }
            }
        ]

    def get_next_actions(self, args):
        """Get user input through terminal and return as string"""
        question = args.get("question", "")
        print(f"\033[93mAI is asking: {question}\033[0m")
        print("\033[93mYour response: \033[0m", end="")
        # If we have a WhatsApp number and this is relevant context, display it
        if self.whatsapp_number:
            print(f"\033[93mUsing WhatsApp number: {self.whatsapp_number}\033[0m")

        # Capture and return whatever the user types
        user_response = input().strip()

        # Return the raw user response
        return user_response

    def add_to_history(self, role: str, content: str) -> None:
        """
        Add a message to the conversation history
        
        Args:
            role: The role of the message sender ('system', 'user', or 'assistant')
            content: The content of the message
        """
        self.conversation_history.append({"role": role, "content": content})

        # Trim history if it gets too long
        if len(self.conversation_history) > self.max_history_length:
            # Keep the first message (usually system) and trim oldest messages
            system_message = None
            if self.conversation_history[0]["role"] == "system":
                system_message = self.conversation_history[0]
                self.conversation_history = self.conversation_history[-(
                    self.max_history_length-1):]
                self.conversation_history.insert(0, system_message)
            else:
                self.conversation_history = self.conversation_history[-self.max_history_length:]

    def clear_history(self) -> None:
        """Clear the conversation history"""
        self.conversation_history = []

    def get_ai_response(self,
                        prompt: str,
                        app_context: str,
                        current_input_type: str,
                        available_options: Optional[List[str]] = None,
                        system_task: str = "",
                        format: str = "json_object") -> str:
        """
        Get a response from the OpenAI API based on conversation history and current prompt
        """
        # Prepare system message
        system_message = f"""
        You are an AI assistant interacting with a CLI application for given task. If you get stuck in loop after 3 trials exit.
        
        Current application: {app_context}
        Current prompt: {prompt}
        Input type expected: {current_input_type}
        
        {system_task}
        
        IMPORTANT: During your interaction with the CLI application:

        1. When you successfully complete a task (e.g., finding hotels, making a booking):
        - FIRST call the get_next_actions function with detailed results
        - Include ALL specific details (hotel names, prices, confirmation numbers, etc.)
        - Example: 
            function_call: get_next_actions
            arguments: {{"task_update": "Successfully booked hotel at Taj Chennai. Rate: ₹12,500/night. Transaction ID: ABC123, Confirmation Number: XYZ789, Check-in: 2025-04-25, Check-out: 2025-04-27"}}

        2. When you need information NOT provided in the original task description:
        - Call the get_next_actions function requesting the specific information
        - Be clear about exactly what you need and why
        - Example:
            function_call: get_next_actions
            arguments: {{"task_update": "I need the lead passenger's first name and contact information to complete this booking. The system requires these details to proceed."}}

        3. When presenting options requiring user decision:
        - Call get_next_actions with numbered options clearly described
        - Example:
            function_call: get_next_actions
            arguments: {{"task_update": "Please select your preferred room type:\\n1. Standard Room (₹8,000/night) - 1 queen bed\\n2. Deluxe Room (₹12,000/night) - 1 king bed\\n3. Family Suite (₹18,000/night) - 1 king bed + 2 twin beds"}}

        After calling the function in any of these cases, continue your CLI interaction with an appropriate CLI_input response.

        IMPORTANT: You MUST respond in JSON format with two fields:
        1. "chain_of_thought": Your reasoning process about how to respond (will not be shown to CLI)
        2. "cli_input": The EXACT text that will be sent directly to the terminal as input

        Ouput
        {{
        "chain_of_thought": "",
        "cli_input": ""
        }}
        """

        if available_options:
            system_message += f"\nThe available options are: {', '.join(available_options)}"
            system_message += "\nYou MUST select one of these options exactly as written in your cli_input."

        if current_input_type == "continuation":
            system_message += "\nThis is a 'Press Enter to continue' prompt, use an empty string for cli_input."

        # Create messages array with system message first
        messages = [{"role": "system", "content": system_message}]

        # Add conversation history
        messages.extend(self.conversation_history)

        try:
            # Always use JSON format
            response_format = {"type": "json_object"}

            # Configure API call parameters
            api_params = {
                "model": self.model_name,
                "messages": messages,
                "response_format": response_format,
                "max_tokens": 500  # Larger limit to accommodate both reasoning and output
            }

            # Add tools parameter conditionally
            if self.enable_functions:
                logger.info(
                    "Function calling enabled. Including tools in API request.")
                api_params["tools"] = self.functions
            else:
                logger.info(
                    "Function calling disabled. Making standard API request.")

            # Call the OpenAI API
            response = self.client.chat.completions.create(**api_params)

            # Handle function calling responses
            if hasattr(response.choices[0].message, 'tool_calls') and response.choices[0].message.tool_calls:
                # Process function calls
                tool_calls = response.choices[0].message.tool_calls
                logger.info(
                    f"Function calling detected! Found {len(tool_calls)} tool call(s)")

                # We need to extract the full tool_calls structure exactly as it appears in the response
                # This includes the required 'type' field
                assistant_message = response.choices[0].message

                # Create a serializable version of the tool_calls
                serializable_tool_calls = []
                for tc in tool_calls:
                    tool_call_data = {
                        "id": tc.id,
                        "type": "function",  # This is the missing required field
                        "function": {
                            "name": tc.function.name,
                            "arguments": tc.function.arguments
                        }
                    }
                    serializable_tool_calls.append(tool_call_data)

                # Add assistant message with properly formatted tool_calls to messages
                messages.append({
                    "role": "assistant",
                    "content": assistant_message.content or "",
                    "tool_calls": serializable_tool_calls
                })

                # Add to conversation history
                history_message = {
                    "role": "assistant",
                    "content": assistant_message.content or "",
                    "has_tool_calls": True
                }
                self.add_to_history("assistant", json.dumps(history_message))

                # Process each function call
                for tool_call in tool_calls:

                    function_name = tool_call.function.name
                    function_args = json.loads(tool_call.function.arguments)
                    logger.info(
                        f"Executing function: {function_name} with args: {json.dumps(function_args)}")

                    # Execute the function
                    if function_name == "get_next_actions":
                        result = self.get_next_actions(function_args)
                        logger.info(
                            f"Function {function_name} returned: {result}")
                    else:
                        result = f"Function {function_name} not implemented"
                        logger.warning(
                            f"Attempted to call unknown function: {function_name}")

                    # Add tool response to messages
                    messages.append({
                        "role": "tool",
                        "tool_call_id": tool_call.id,
                        "content": result
                    })

                logger.info(
                    "Making follow-up API call with function results...")

                # Make a follow-up call WITHOUT tools to get final response
                final_response = self.client.chat.completions.create(
                    model=self.model_name,
                    messages=messages,
                    response_format={"type": "json_object"}
                )

                logger.info("Received final response after function execution")
                response = final_response

            # Get the response text
            response_text = response.choices[0].message.content

            # Check if content exists (may be None for some tool calls)
            if response_text is None:
                logger.error("Response content is None")
                return "error: empty response"

            response_json = response_text.strip()

            try:
                # Parse the JSON response
                parsed_response = json.loads(response_json)

                # Extract the CLI output
                cli_input = parsed_response.get("cli_input", "")

                # Log both parts
                logger.info(
                    f"AI reasoning: {parsed_response.get('chain_of_thought', 'No reasoning provided')}")
                logger.info(f"AI CLI output: {cli_input}")

                # Add the full JSON response to the conversation history
                self.add_to_history("assistant", response_json)

                # Return just the CLI output
                return cli_input

            except json.JSONDecodeError:
                logger.error(f"Failed to parse JSON response: {response_json}")
                return "error: invalid response format"

        except Exception as e:
            error_message = f"Error in OpenAI API call: {str(e)}"
            logger.error(error_message)
            return "error"

    def get_detailed_response(self,
                              query: str,
                              app_context: str,
                              history: List[Dict[str, str]] = None,
                              format: str = "text") -> str:
        """
        Get a more detailed response for analysis or explanation
        (used outside the direct CLI interaction flow)
        
        Args:
            query: The user's query or request
            app_context: The application context
            history: Optional conversation history to include
            format: Output format ("text" or "json_object")
            
        Returns:
            The AI response text
        """
        # Prepare system message
        system_message = f"""
        You are an AI assistant helping a user with a CLI application.
        
        Current application: {app_context}
        
        Provide detailed guidance and explanations to help the user.
        """

        # Create messages array with system message first
        messages = [{"role": "system", "content": system_message}]

        # Add optional history
        if history:
            messages.extend(history)

        # Add the user query
        messages.append({"role": "user", "content": query})

        try:
            response_format = {"type": "text"}
            if format == "json_object":
                response_format = {"type": "json_object"}

            # Call the OpenAI API
            response = self.client.chat.completions.create(
                model=self.model_name,
                messages=messages,
                response_format=response_format
            )

            # Get the response text
            response_text = response.choices[0].message.content

            return response_text

        except Exception as e:
            error_message = f"Error in OpenAI API call: {str(e)}"
            logger.error(error_message)
            return f"Error: {str(e)}"


# Example usage:
if __name__ == "__main__":
    # Test the OpenAI handler
    handler = OpenAIHandler()

    # Example CLI interaction
    response = handler.get_ai_response(
        prompt="Enter your name:",
        app_context="hotel",
        current_input_type="text"
    )

    print(f"Test response: {response}")
