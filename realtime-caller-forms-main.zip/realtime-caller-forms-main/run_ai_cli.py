#!/usr/bin/env python3
"""
AI CLI Runner - Main Launch Script
Runs CLI applications with AI assistance using OpenAI API
"""
from ai_runner_integration import AIRunner
import argparse
import sys
import os
from dotenv import load_dotenv
load_dotenv()


def main():
    """Parse command line arguments and start the AI Runner"""
    parser = argparse.ArgumentParser(
        description='Run CLI applications with AI assistance')

    # Add command line arguments
    parser.add_argument('--model', type=str, default='gpt-4o-mini',
                        help='OpenAI model to use (default: gpt-4o-mini)')
    parser.add_argument('--api-key', type=str,
                        help='OpenAI API key (default: uses OPENAI_API_KEY environment variable)')
    parser.add_argument('--system-task', type=str,
                        help='Custom system task instruction for the AI')
    parser.add_argument('--task-file', type=str,
                        help='File containing system task instructions for the AI')
    parser.add_argument('--app-type', type=str, choices=['form'],
                        help='Application type to run (bypasses interactive selection)')
    parser.add_argument('--mode', type=int, choices=[1, 2, 3],
                        help='Interaction mode: 1=Manual, 2=AI suggestions, 3=AI auto (bypasses interactive selection)')
    parser.add_argument('--batch-mode', action='store_true',
                        help='Exit after completing the task instead of showing interactive menu')
    parser.add_argument('--whatsapp-number', type=str, default=None,
                        help='WhatsApp number to use (default: None)')
    parser.add_argument('--enable-functions', action='store_true',
                    help='Enable function calling for AI responses')

    # Parse arguments
    args = parser.parse_args()


    # After parsing arguments
    print(
        f"\033[36mCommand line args - enable_functions: {args.enable_functions}\033[0m")

    # Check for API key in args or environment
    api_key = args.api_key or os.getenv("OPENAI_API_KEY")

    # Verify API key exists
    if not api_key:
        print("\033[91mWarning: No OpenAI API key found. Please set the OPENAI_API_KEY environment variable or use --api-key.\033[0m")
        print("You can set it with:")
        print("  export OPENAI_API_KEY=your_api_key  # On Linux/Mac")
        print("  set OPENAI_API_KEY=your_api_key     # On Windows CMD")
        print("  $env:OPENAI_API_KEY='your_api_key'  # On Windows PowerShell")

        # Ask if user wants to continue without API key (will use simulated responses)
        print("\nDo you want to continue without an API key? (y/n)")
        answer = input("> ").lower()
        if answer != 'y':
            print("Exiting...")
            sys.exit(1)

    # Load system task
    system_task = args.system_task
    if args.task_file:
        try:
            with open(args.task_file, 'r', encoding='utf-8') as f:
                system_task = f.read().strip()
            print(f"Loaded system task from file: {args.task_file}")
        except Exception as e:
            print(f"\033[91mError loading system task file: {str(e)}\033[0m")
            sys.exit(1)

    print(f"Using model: {args.model}")


    # Right before creating the runner
    print(
        f"\033[36mCreating AIRunner with enable_functions={args.enable_functions}\033[0m")

    # Create the runner
    runner = AIRunner(
        api_key=api_key,
        model_name=args.model,
        system_task=system_task,
        batch_mode=args.batch_mode,
        enable_functions=args.enable_functions,
        whatsapp_number=args.whatsapp_number  # Add this line
    )

    # First, check if all required parameters are specified for direct launch
    if args.app_type and args.mode:
        # Set interaction mode based on command line argument
        if args.mode == 1:
            # Manual mode
            runner.auto_mode = False
            runner.always_show_ai_suggestion = False
            print(
                f"\nManual mode selected for {args.app_type} CLI. You will provide all inputs.")
        elif args.mode == 2:
            # AI suggestion mode
            runner.auto_mode = False
            runner.always_show_ai_suggestion = True
            print(
                f"\nAI suggestion mode selected for {args.app_type} CLI. AI will suggest responses, but you confirm each one.")
        elif args.mode == 3:
            # Full auto mode
            runner.auto_mode = True
            runner.always_show_ai_suggestion = False
            print(
                f"\nAI auto mode selected for {args.app_type} CLI. AI will automatically respond to all prompts.")

        # Start the application directly
        runner.start(args.app_type)

        # If batch mode, exit after completion
        if args.batch_mode:
            sys.exit(0)
    else:
        # Fall back to interactive prompt if either app_type or mode is missing
        runner.prompt_for_app_type()


if __name__ == "__main__":
    main()
