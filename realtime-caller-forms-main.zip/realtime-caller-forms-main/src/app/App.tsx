// App.tsx

"use client";

import React, { useEffect, useRef, useState } from "react";
import { v4 as uuidv4 } from "uuid";

// UI components
import OptimoVoiceUI from "./components/OptimoVoiceUI";

// Types
import { AgentConfig, SessionStatus } from "@/app/types";

// Context providers & hooks
import { useTranscript } from "@/app/contexts/TranscriptContext";
import { useEvent } from "@/app/contexts/EventContext";
import { useHandleServerEvent } from "./hooks/useHandleServerEvent";

// Utilities
import { createRealtimeConnection } from "./lib/realtimeConnection";

// Agent configs
import { allAgentSets } from "@/app/agentConfigs";
import { Form } from "./components/Form";

function App() {
  const [isFormReviewMode, setIsFormReviewMode] = useState<boolean>(false);
  const {
    transcriptItems,
    addTranscriptMessage,
    addTranscriptBreadcrumb,
    clearTranscript,
  } = useTranscript();
  const { logClientEvent, logServerEvent } = useEvent();

  // Always use optimoLoanAgent
  const [selectedAgentName, setSelectedAgentName] = useState<string>("");
  const [selectedAgentConfigSet, setSelectedAgentConfigSet] = useState<AgentConfig[] | null>(null);

  const [dataChannel, setDataChannel] = useState<RTCDataChannel | null>(null);
  const pcRef = useRef<RTCPeerConnection | null>(null);
  const dcRef = useRef<RTCDataChannel | null>(null);
  const audioElementRef = useRef<HTMLAudioElement | null>(null);
  const [sessionStatus, setSessionStatus] = useState<SessionStatus>("DISCONNECTED");

  const [conversationStartTime, setConversationStartTime] = useState<number>(0);
  const [isAudioPlaybackEnabled, setIsAudioPlaybackEnabled] = useState<boolean>(true);

  // Add these states from the original App.tsx for proper voice handling
  const [isPTTActive, setIsPTTActive] = useState<boolean>(false);
  const [isPTTUserSpeaking, setIsPTTUserSpeaking] = useState<boolean>(false);

  const [isFormResultLoading, setIsFormResultLoading] = useState(false);
  const [formResult, setFormResult] = useState<object | null>(null);

  const sendClientEvent = (eventObj: any, eventNameSuffix = "") => {
    if (dcRef.current && dcRef.current.readyState === "open") {
      logClientEvent(eventObj, eventNameSuffix);
      dcRef.current.send(JSON.stringify(eventObj));
    } else {
      logClientEvent(
        { attemptedEvent: eventObj.type },
        "error.data_channel_not_open"
      );
      console.error("Failed to send message - no data channel available", eventObj);
    }
  };

  const handleServerEventRef = useHandleServerEvent({
    setSessionStatus,
    selectedAgentName,
    selectedAgentConfigSet,
    sendClientEvent,
    setSelectedAgentName,
  });

  // Initialize with optimoLoanAgent on mount
  useEffect(() => {
    const optimoAgents = allAgentSets.optimoLoanAgent;
    if (optimoAgents && optimoAgents.length > 0) {
      setSelectedAgentName(optimoAgents[0].name);
      setSelectedAgentConfigSet(optimoAgents);
    }
  }, []);

  // Auto-connect when agent is selected
  useEffect(() => {
    if (selectedAgentName && sessionStatus === "DISCONNECTED") {
      connectToRealtime();
    }
  }, [selectedAgentName]);

  // Update session when connected
  useEffect(() => {
    if (sessionStatus === "CONNECTED" && selectedAgentConfigSet && selectedAgentName) {
      const currentAgent = selectedAgentConfigSet.find(a => a.name === selectedAgentName);
      addTranscriptBreadcrumb(`Agent: ${selectedAgentName}`, currentAgent);
      updateSession(true);
      setConversationStartTime(Date.now());
    }
  }, [selectedAgentConfigSet, selectedAgentName, sessionStatus]);

  // Handle PTT mode changes like in original
  useEffect(() => {
    if (sessionStatus === "CONNECTED") {
      console.log(`updatingSession, isPTTActive=${isPTTActive} sessionStatus=${sessionStatus}`);
      updateSession();
    }
  }, [isPTTActive]);

  const fetchEphemeralKey = async (): Promise<string | null> => {
    logClientEvent({ url: "/session" }, "fetch_session_token_request");
    const tokenResponse = await fetch("/api/session");
    const data = await tokenResponse.json();
    logServerEvent(data, "fetch_session_token_response");

    if (!data.client_secret?.value) {
      logClientEvent(data, "error.no_ephemeral_key");
      console.error("No ephemeral key provided by the server");
      setSessionStatus("DISCONNECTED");
      return null;
    }

    return data.client_secret.value;
  };

  const connectToRealtime = async () => {
    if (sessionStatus !== "DISCONNECTED") return;
    setSessionStatus("CONNECTING");

    try {
      const EPHEMERAL_KEY = await fetchEphemeralKey();
      if (!EPHEMERAL_KEY) {
        return;
      }

      // Set up audio element exactly like the original
      if (!audioElementRef.current) {
        audioElementRef.current = document.createElement("audio");
      }
      audioElementRef.current.autoplay = isAudioPlaybackEnabled;

      // Use the existing realtimeConnection function
      const { pc, dc } = await createRealtimeConnection(EPHEMERAL_KEY, audioElementRef);
      pcRef.current = pc;
      dcRef.current = dc;

      // Set up event listeners exactly like the original
      dc.addEventListener("open", () => {
        logClientEvent({}, "data_channel.open");
      });
      dc.addEventListener("close", () => {
        logClientEvent({}, "data_channel.close");
      });
      dc.addEventListener("error", (err: any) => {
        logClientEvent({ error: err }, "data_channel.error");
      });
      dc.addEventListener("message", (e: MessageEvent) => {
        handleServerEventRef.current(JSON.parse(e.data));
      });

      setDataChannel(dc);
    } catch (err) {
      console.error("Error connecting to realtime:", err);
      setSessionStatus("DISCONNECTED");
    }
  };

  const disconnectFromRealtime = () => {
    if (pcRef.current) {
      pcRef.current.getSenders().forEach((sender) => {
        if (sender.track) {
          sender.track.stop();
        }
      });
      pcRef.current.close();
      pcRef.current = null;
    }
    setDataChannel(null);
    setSessionStatus("DISCONNECTED");
    setConversationStartTime(0);
    setIsPTTUserSpeaking(false);
    logClientEvent({}, "disconnected");
  };

  const sendSimulatedUserMessage = (text: string) => {
    const id = uuidv4().slice(0, 32);
    addTranscriptMessage(id, "user", text, true);

    sendClientEvent({
      type: "conversation.item.create",
      item: {
        id,
        type: "message",
        role: "user",
        content: [{ type: "input_text", text }],
      },
    }, "(simulated user text message)");
    sendClientEvent({ type: "response.create" }, "(trigger response after simulated user text message)");
  };

  const updateSession = (shouldTriggerResponse: boolean = false) => {
    sendClientEvent({ type: "input_audio_buffer.clear" }, "clear audio buffer on session update");

    const currentAgent = selectedAgentConfigSet?.find(a => a.name === selectedAgentName);

    // Keep the PTT logic from original - this is what allows voice to work
    const turnDetection = isPTTActive
      ? null
      : {
        type: "server_vad",
        threshold: 0.5,
        prefix_padding_ms: 300,
        silence_duration_ms: 200,
        create_response: true,
      };

    const instructions = currentAgent?.instructions || "";
    const tools = currentAgent?.tools || [];

    const sessionUpdateEvent = {
      type: "session.update",
      session: {
        modalities: ["text", "audio"],
        instructions,
        voice: "coral",
        input_audio_format: "pcm16",
        output_audio_format: "pcm16",
        input_audio_transcription: { model: "whisper-1" },
        turn_detection: turnDetection,
        tools,
      },
    };

    sendClientEvent(sessionUpdateEvent);

    if (shouldTriggerResponse) {
      sendSimulatedUserMessage("hi");
    }
  };

  // Cancel assistant speech function from original
  const cancelAssistantSpeech = async () => {
    const mostRecentAssistantMessage = [...transcriptItems]
      .reverse()
      .find((item) => item.role === "assistant");

    if (!mostRecentAssistantMessage) {
      console.warn("can't cancel, no recent assistant message found");
      return;
    }
    if (mostRecentAssistantMessage.status === "DONE") {
      console.log("No truncation needed, message is DONE");
      return;
    }

    sendClientEvent({
      type: "conversation.item.truncate",
      item_id: mostRecentAssistantMessage?.itemId,
      content_index: 0,
      audio_end_ms: Date.now() - mostRecentAssistantMessage.createdAtMs,
    });
    sendClientEvent(
      { type: "response.cancel" },
      "(cancel due to user interruption)"
    );
  };

  // PTT functions from original
  const handleTalkButtonDown = () => {
    if (sessionStatus !== "CONNECTED" || dataChannel?.readyState !== "open") return;
    cancelAssistantSpeech();

    setIsPTTUserSpeaking(true);
    sendClientEvent({ type: "input_audio_buffer.clear" }, "clear PTT buffer");
  };

  const handleTalkButtonUp = () => {
    if (
      sessionStatus !== "CONNECTED" ||
      dataChannel?.readyState !== "open" ||
      !isPTTUserSpeaking
    ) return;

    setIsPTTUserSpeaking(false);
    sendClientEvent({ type: "input_audio_buffer.commit" }, "commit PTT");
    sendClientEvent({ type: "response.create" }, "trigger response PTT");
  };

  const handleFinishConversation = async (messageTranscriptions: object[]) => {
    setIsFormReviewMode(true);
    disconnectFromRealtime();
    setIsFormResultLoading(true);
    try {
      const response = await fetch('http://3.111.213.182:4000/summarize', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(messageTranscriptions),
      });
      const data = await response.json();
      setFormResult(data);
    } catch (error) {
      console.error("Error submitting form result:", error);
    } finally {
      setIsFormResultLoading(false);
    }
  };

  // Calculate conversation duration
  // const conversationDuration = conversationStartTime > 0
  //   ? Math.floor((Date.now() - conversationStartTime) / 1000)
  //   : 0;

  // Audio playing detection like original
  const isAISpeaking = sessionStatus === "CONNECTED" && audioElementRef.current ? !audioElementRef.current.paused : false;

  // User speaking logic exactly like original
  const isUserSpeaking = isPTTUserSpeaking || (sessionStatus === "CONNECTED" && !isPTTActive);

  // Initialize localStorage settings like in original
  useEffect(() => {
    const storedPushToTalkUI = localStorage.getItem("pushToTalkUI");
    if (storedPushToTalkUI) {
      setIsPTTActive(storedPushToTalkUI === "true");
    }
    const storedAudioPlaybackEnabled = localStorage.getItem("audioPlaybackEnabled");
    if (storedAudioPlaybackEnabled) {
      setIsAudioPlaybackEnabled(storedAudioPlaybackEnabled === "true");
    }
  }, []);

  useEffect(() => {
    localStorage.setItem("pushToTalkUI", isPTTActive.toString());
  }, [isPTTActive]);

  useEffect(() => {
    localStorage.setItem("audioPlaybackEnabled", isAudioPlaybackEnabled.toString());
  }, [isAudioPlaybackEnabled]);

  useEffect(() => {
    if (audioElementRef.current) {
      if (isAudioPlaybackEnabled) {
        audioElementRef.current.play().catch((err) => {
          console.warn("Autoplay may be blocked by browser:", err);
        });
      } else {
        audioElementRef.current.pause();
      }
    }
  }, [isAudioPlaybackEnabled]);

  return (
    <div className="flex flex-col h-full bg-gray-50">
      {/* Simple header */}
      <div className="p-4 bg-white shadow-sm">
        <h1 className="text-xl font-semibold text-gray-800">
          Optimo Loan Assistant
        </h1>
      </div>

      {/* Main content */}
      <div className="flex-1 relative h-full">
        {!isFormReviewMode ? (
          <OptimoVoiceUI
            isUserSpeaking={isUserSpeaking}
            isAISpeaking={isAISpeaking}
            onFinishConversation={handleFinishConversation}
            onDisconnect={sessionStatus === "DISCONNECTED" ? connectToRealtime : disconnectFromRealtime}
            sessionStatus={sessionStatus}
            selectedAgentName={selectedAgentName}
            selectedAgentConfigSet={selectedAgentConfigSet}
            // Add PTT support
            isPTTActive={isPTTActive}
            setIsPTTActive={setIsPTTActive}
            handleTalkButtonDown={handleTalkButtonDown}
            handleTalkButtonUp={handleTalkButtonUp}
            isPTTUserSpeaking={isPTTUserSpeaking}
          />
        ) : (
          <div className="flex items-center justify-center h-full p-8">
            <div className="max-w-md text-center">
              <h2 className="text-2xl font-bold mb-4">Application Submitted</h2>
              <p className="text-gray-600 mb-6">
                Thank you for completing your loan application. Our team will review your information and get back to you soon.
              </p>
              <button
                onClick={() => {
                  setIsFormReviewMode(false);
                  setConversationStartTime(0);
                  clearTranscript();
                }}
                className="px-6 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition"
              >
                Start New Application
              </button>
            </div>
          </div>
        )}
      </div>

      {isFormResultLoading && (
        <div className="absolute inset-0 flex items-center justify-center text-2xl bg-black bg-opacity-80 z-50">
          Submitting...
        </div>
      )}

      {formResult && (
        <Form
          data={formResult}
          handleSubmit={() => setFormResult(null)}
        />
      )}
    </div>
  );
}

export default App;