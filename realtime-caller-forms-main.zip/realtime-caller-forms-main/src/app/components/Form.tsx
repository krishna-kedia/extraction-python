import { allQuestions } from "../agentConfigs/optimo_form/hinglishLoanAgent";

type FormProps = {
    data?: object; // Define the type of data if needed
    handleSubmit: () => void; // Optional submit handler
};

export const Form = ({ data, handleSubmit }: FormProps) => {
    return (
        <div className="fixed inset-0 flex items-center justify-center bg-gray-800 bg-opacity-50 z-50">
            <div className="bg-white max-h-[600px] overflow-y-scroll rounded-lg shadow-lg p-6 w-full max-w-xl">
                <h2 className="text-xl text-gray-600 font-semibold mb-4">Loan Application Form</h2>
                <form onSubmit={(e) => {
                    e.preventDefault();
                    handleSubmit();
                }}>
                    {allQuestions.map((question) => (
                        <div key={question.id} className="mb-4">
                            <label
                                htmlFor={question.id}
                                className="block text-sm font-medium text-gray-700"
                            >
                                {question.question}
                                {question.required && <span className="text-red-500">*</span>}
                            </label>
                            <input
                                type="text"
                                id={question.id}
                                name={question.id}
                                defaultValue={data ? (data as any)[question.id] : ""}
                                required={question.required}
                                className={`mt-1 p-2 text-gray-600 block w-full border-2 border-gray-300 rounded-md shadow-sm focus:border-indigo-500 focus:ring-indigo-500 ${
                                question.complete ? "bg-green-100" : ""
                                }`}
                            />
                        </div>
                    ))}
                    <button
                        type="submit"
                        className="w-full bg-blue-600 text-white py-2 px-4 rounded hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
                    >
                        Submit
                    </button>
                </form>
            </div>
        </div>
    );
};
