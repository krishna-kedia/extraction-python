// src/app/components/OptimoVoiceUI.tsx
import React, { useEffect, useMemo, useRef } from 'react';
import { useTranscript } from '../contexts/TranscriptContext';

type OptimoVoiceUIProps = {
    isUserSpeaking: boolean;
    isAISpeaking: boolean;
    onFinishConversation: (messageTranscriptions: any) => void;
    onDisconnect: () => void;
    sessionStatus: 'DISCONNECTED' | 'CONNECTING' | 'CONNECTED';
    selectedAgentName: string;
    selectedAgentConfigSet: Array<{ name: string; instructions?: string }> | null;
    // PTT props
    isPTTActive: boolean;
    setIsPTTActive: (active: boolean) => void;
    handleTalkButtonDown: () => void;
    handleTalkButtonUp: () => void;
    isPTTUserSpeaking: boolean;
};

const OptimoVoiceUI: React.FC<OptimoVoiceUIProps> = ({
    isUserSpeaking,
    isAISpeaking,
    onFinishConversation,
    onDisconnect,
    sessionStatus,
    selectedAgentName,
    isPTTActive,
    setIsPTTActive,
    handleTalkButtonDown,
    handleTalkButtonUp,
    isPTTUserSpeaking,
}) => {
    const { transcriptItems } = useTranscript();
    const messageWindowRef = useRef<HTMLDivElement>(null);

    const messageTranscriptions = useMemo(() => {
        return transcriptItems
        .filter(item => item.type === "MESSAGE")
        .map((item) => ({
            id: item.itemId,
            role: item.role,
            message: item.title,
        }));
    }, [transcriptItems]);

    // Get status info based on current state
    const getStatusInfo = () => {
        if (sessionStatus === 'DISCONNECTED') {
            return {
                text: 'Ready to connect',
                color: 'bg-gray-500',
                icon: '🔗'
            };
        }

        if (sessionStatus === 'CONNECTING') {
            return {
                text: 'Connecting...',
                color: 'bg-yellow-500 animate-pulse',
                icon: '⏳'
            };
        }

        if (isUserSpeaking) {
            return {
                text: isPTTActive ? 'Hold to speak' : 'You are speaking',
                color: 'bg-green-500 scale-110',
                icon: '🎤'
            };
        }

        if (isAISpeaking) {
            return {
                text: 'Assistant is speaking',
                color: 'bg-blue-500 scale-110',
                icon: '🔊'
            };
        }

        return {
            text: isPTTActive ? 'Press and hold to speak' : 'Listening...',
            color: 'bg-blue-400',
            icon: isPTTActive ? '🎙️' : '👂'
        };
    };

    const statusInfo = getStatusInfo();

    useEffect(() => {
        if (messageWindowRef.current) {
            messageWindowRef.current.scrollTo({
                top: messageWindowRef.current.scrollHeight,
                behavior: 'smooth'
            });
        }
    }, [messageTranscriptions]);

    return (
        <div className="flex h-full p-8 bg-gradient-to-br from-blue-50 to-indigo-100">
            <div className="flex flex-1 flex-col items-center justify-center">
                {/* Voice indicator circle */}
                <div className={`
                    w-48 h-48 rounded-full flex items-center justify-center transition-all duration-300 ease-in-out
                    ${statusInfo.color} shadow-lg
                `}>
                    <div className="text-white text-center">
                        <div className="text-6xl mb-2">{statusInfo.icon}</div>
                        <div className="text-lg font-medium">{statusInfo.text}</div>
                    </div>
                </div>

                {/* PTT Controls */}
                {sessionStatus === 'CONNECTED' && (
                    <div className="mt-6 flex items-center gap-4">
                        <label className="flex items-center gap-2 text-gray-700">
                            <input
                                type="checkbox"
                                checked={isPTTActive}
                                onChange={(e) => setIsPTTActive(e.target.checked)}
                                className="w-4 h-4"
                            />
                            Push to Talk Mode
                        </label>

                        {isPTTActive && (
                            <button
                                onMouseDown={handleTalkButtonDown}
                                onMouseUp={handleTalkButtonUp}
                                onTouchStart={handleTalkButtonDown}
                                onTouchEnd={handleTalkButtonUp}
                                className={`px-6 py-3 rounded-lg font-medium transition-all duration-200 ${isPTTUserSpeaking
                                        ? 'bg-red-500 text-white scale-105'
                                        : 'bg-gray-600 text-white hover:bg-gray-700'
                                    }`}
                            >
                                {isPTTUserSpeaking ? 'Speaking...' : 'Hold to Talk'}
                            </button>
                        )}
                    </div>
                )}

                {/* Status message */}
                <div className="mt-6 text-center max-w-md">
                    {sessionStatus === 'CONNECTED' ? (
                        <p className="text-lg text-gray-700">
                            {isPTTActive
                                ? 'Press and hold the "Hold to Talk" button to speak with the assistant.'
                                : 'Speak naturally about your loan requirements. The assistant will guide you through the application process.'
                            }
                        </p>
                    ) : sessionStatus === 'CONNECTING' ? (
                        <p className="text-lg text-gray-600">
                            Please wait while we connect you to our loan assistant...
                        </p>
                    ) : (
                        <p className="text-lg text-gray-600">
                            Click the connect button to start your loan application conversation.
                        </p>
                    )}
                </div>

                {/* Action buttons */}
                <div className="mt-10 flex gap-4">
                    {sessionStatus === 'CONNECTED' ? (
                        <>
                            <button
                                onClick={() => onFinishConversation(messageTranscriptions)}
                                className="px-8 py-4 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors font-medium text-lg shadow-lg"
                            >
                                Complete Application
                            </button>
                            <button
                                onClick={onDisconnect}
                                className="px-8 py-4 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors font-medium text-lg shadow-lg"
                            >
                                Disconnect
                            </button>
                        </>
                    ) : (
                        <button
                            onClick={onDisconnect}
                            disabled={sessionStatus === 'CONNECTING'}
                            className={`px-8 py-4 rounded-lg font-medium text-lg shadow-lg transition-colors ${sessionStatus === 'CONNECTING'
                                    ? 'bg-gray-400 text-gray-600 cursor-not-allowed'
                                    : 'bg-indigo-600 text-white hover:bg-indigo-700'
                                }`}
                        >
                            {sessionStatus === 'CONNECTING' ? 'Connecting...' : 'Start Conversation'}
                        </button>
                    )}
                </div>

                {/* Instructions */}
                {sessionStatus === 'CONNECTED' && (
                    <div className="mt-8 text-center text-gray-600 max-w-lg">
                        <p className="text-sm">
                            💡 <strong>Tip:</strong> You can speak in Hindi, English, or mix both languages.
                            When you've provided all the required information, click "Complete Application".
                        </p>
                    </div>
                )}
            </div>

            {/* Messages */}
            {/* <div
                ref={messageWindowRef}
                className="overflow-y-auto p-6 h-[600px]"
            >
                {messageTranscriptions.map((item) => (
                    <div
                        key={item.id}
                        className={`mt-4 p-4 ${item.role === 'user' ? 'bg-indigo-500 text-white' : 'bg-white text-gray-600'} rounded-lg shadow-md w-full max-w-md`}
                    >
                        <strong>{item.role}:</strong> {item.message}
                    </div>
                ))}
            </div> */}
        </div>
    );
};

export default OptimoVoiceUI;