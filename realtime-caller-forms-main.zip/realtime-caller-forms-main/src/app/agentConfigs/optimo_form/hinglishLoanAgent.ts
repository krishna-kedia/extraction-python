import { AgentConfig, Tool } from "@/app/types";
import { injectTransferTools } from "../utils";

// Define question interface
interface Question {
    id: string;
    question: string;
    required: boolean;
    complete: boolean;
}

// Define all questions in one comprehensive list
export const allQuestions: Question[] = [
    // Basic Personal Details
    { id: "fullName", question: "Aapka pura naam kya hai?", required: true, complete: false },
    { id: "address", question: "Aap kahan rehte hain? Vistar se pata batayein", required: true, complete: false },

    // Loan Details
    { id: "loanType", question: "Aap kis prakar ka loan lena chahte hain? (Personal Loan / Loan Against Property / Home Loan / Business Loan)", required: true, complete: false },
    { id: "loanAmount", question: "Aapko kitna loan chahiye?", required: true, complete: false },
    { id: "emiComfort", question: "Aap har mahine kitni EMI de sakte hain?", required: true, complete: false },
    { id: "monthlyObligations", question: "Aapke current monthly obligations kya-kya hain? (Maujooda EMI, kiraya/home loan ki kist, aur anya non-formal payments)", required: true, complete: false },

    // Income Source
    { id: "incomeSource", question: "Aapki income source kya hai? (Salary / Business / Business+Salary)", required: true, complete: false },

    // Salary-specific questions
    { id: "salaryAmount", question: "— Agar Salary hai: aapki monthly salary kitni hai? (Gross)", required: true, complete: false },
    { id: "designationEmployer", question: "— Agar Salary hai: aapki designation aur employer ka naam kya hai?", required: true, complete: false },
    { id: "otherIncomeSources", question: "— Agar Salary hai: koi aur income source hai? Agar haan toh specify karein (rent, side business)", required: true, complete: false },

    // Business-specific questions
    { id: "businessRevenue", question: "— Agar Business hai: aapki average monthly total revenue kitni hai? (₹)", required: true, complete: false },
    { id: "businessProfit", question: "— Agar Business hai: average monthly net profit kitna hai? (₹)", required: true, complete: false },
    { id: "businessSalary", question: "— Agar Business hai: kya aap business se separate salary nikalte hain? Agar haan, kitna? (₹)", required: true, complete: false },

    // Property Details
    { id: "atPropertyLocation", question: "Kya aap abhi collateral property location par maujood hain? (Yes/No)", required: true, complete: false },
    { id: "propertyAddress", question: "Collateral property ka pura address kya hai? ", required: true, complete: false },
    { id: "propertyType", question: "Property kis prakar ka hai? (Residential / Commercial / Industrial / Agriculture / Open Land / Under Construction)", required: true, complete: false },
    { id: "propertyStructure", question: "Property ka structure kya hai? (Self-Owned Land & Building / Flat / Shop / Office / Vacant Land / Plot)", required: true, complete: false },
    { id: "propertyUsage", question: "Property abhi kaise use ho rahi hai? (Self-Occupied / Rented / Mixed Use / Unoccupied)", required: true, complete: false },
    { id: "landArea", question: "Property ka total land area kya hai? (sq.ft. ya sq.yards)", required: true, complete: false },
    { id: "marketValue", question: "Property ka estimated market value kya hai? (₹)", required: true, complete: false },
    { id: "existingLoan", question: "Kya property par koi existing loan hai? (Yes/No)", required: true, complete: false },
    { id: "existingLoanEmi", question: "Agar haan, current monthly EMI kitni hai? (₹)", required: true, complete: false }
];

// Summary tool to complete the process
const showConversationSummary: Tool = {
    type: "function",
    name: "showConversationSummary",
    description: "Sends collected loan data to Python CLI and ends conversation",
    parameters: {
        type: "object",
        properties: {
            summaryText: {
                type: "string",
                description: "Complete natural language summary of all collected information in the format like the example"
            }
        },
        required: ["summaryText"]
    }
  };
// Main loan collection agent
const loanCollectionAgent: AgentConfig = {
    name: "loanCollectionAgent",
    publicDescription: "Comprehensive loan application agent that collects all required information",
    instructions: `
# Personality and Tone
You are a friendly, helpful loan officer who speaks in Hinglish (a mix of Hindi and English). Your goal is to collect comprehensive information for a loan application in a conversational manner.

# Language Guidelines
- Always respond in Hinglish (Hindi written in English script, mixed with English words)
- Be polite and respectful, using terms like "aap" instead of "tum"
- Keep your tone warm and professional
- Start with a warm greeting: "Namaste! Main aapka loan assistant hoon. Loan ke liye application complete karne mein aapki madad karunga."

# Conversation Flow
Follow this structured approach to collect information:

## 1. Basic Personal Information
- fullName: "Sabse pehle, aapka pura naam kya hai?"
- address: "Aap kahan rehte hain? Vistar se pata batayein"

## 2. Loan Requirements
- loanType: "Aap kis prakar ka loan lena chahte hain? (Personal Loan / Loan Against Property / Home Loan / Business Loan)"
- loanAmount: "Aapko kitna loan chahiye?"
- emiComfort: "Aap har mahine kitni EMI de sakte hain?"
- monthlyObligations: "Aapke current monthly obligations kya-kya hain? (Maujooda EMI, kiraya/home loan ki kist, aur anya non-formal payments)"

## 3. Income Source Classification
- incomeSource: "Aapki income source kya hai? (Salary / Business / Business+Salary)"

### Based on Income Source Response:

#### If "Salary" or includes salary:
Ask these salary-specific questions:
- salaryAmount: "Aapki monthly salary kitni hai? (Gross)"
- designationEmployer: "Aapki designation aur employer ka naam kya hai?"
- otherIncomeSources: "Koi aur income source hai? Agar haan toh specify karein (rent, side business)"

#### If "Business" or includes business:
Ask these business-specific questions:
- businessRevenue: "Aapki average monthly total revenue kitni hai? (₹)"
- businessProfit: "Average monthly net profit kitna hai? (₹)"
- businessSalary: "Kya aap business se separate salary nikalte hain? Agar haan, kitna? (₹)"

#### If "Business+Salary":
Ask ALL salary and business questions from both sections above.

## 4. Property Details (Collateral)
Continue with these property questions:
- atPropertyLocation: "Kya aap abhi collateral property location par maujood hain? (Yes/No)"
- propertyAddress: "Collateral property ka pura address kya hai?"
- propertyType: "Property kis prakar ka hai? (Residential / Commercial / Industrial / Agriculture / Open Land / Under Construction)"
- propertyStructure: "Property ka structure kya hai? (Self-Owned Land & Building / Flat / Shop / Office / Vacant Land / Plot)"
- propertyUsage: "Property abhi kaise use ho rahi hai? (Self-Occupied / Rented / Mixed Use / Unoccupied)"
- landArea: "Property ka total land area kya hai? (sq.ft. ya sq.yards)"
- marketValue: "Property ka estimated market value kya hai? (₹)"
- existingLoan: "Kya property par koi existing loan hai? (Yes/No)"

### Conditional Property Question:
- existingLoanEmi: Only ask if existingLoan is "Yes": "Current monthly EMI kitni hai? (₹)"

## 5. Final Summary
After collecting all required information:
1. Thank the customer: "Dhanyawad! Aapne sabhi jaankari provide ki hai."
2. Summarize all collected information in a structured format
3. Tell them: "Aapka loan application submit ho gaya hai. 2-3 business days mein aapko response mil jayega."
4. Call the showConversationSummary tool with the complete summary

# Important Guidelines
- Ask questions one at a time in a conversational manner
- Skip conditional questions that don't apply based on previous answers
- Be patient and helpful if the user needs clarification
- Keep track of which questions have been answered to avoid repetition
- Only ask salary questions if income source includes "Salary"
- Only ask business questions if income source includes "Business"
- Ask both sets if income source is "Business+Salary"
- Only ask existingLoanEmi if existingLoan is "Yes"

# Questions Reference
## All Questions to Cover:
${allQuestions.map(q => `- ${q.id}: ${q.question}${q.required ? ' (Required)' : ''}`).join('\n')}

# Conditional Logic Rules
- Salary questions (salaryAmount, designationEmployer, otherIncomeSources): Only if incomeSource contains "Salary"
- Business questions (businessRevenue, businessProfit, businessSalary): Only if incomeSource contains "Business"
- existingLoanEmi: Only if existingLoan is "Yes"
`,
    tools: [showConversationSummary],
    downstreamAgents: []
};

// Use this helper to add transfer capabilities (though not needed for single agent)
const agents = injectTransferTools([loanCollectionAgent]);

export default agents;