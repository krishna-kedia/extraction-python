import { AllAgentConfigsType } from "@/app/types";
import frontDeskAuthentication from "./frontDeskAuthentication";
import customerServiceRetail from "./customerServiceRetail";
import simpleExample from "./simpleExample";
import hinglishLoanAgent from "./optimo_form/hinglishLoanAgent"; // newly added import

export const allAgentSets: AllAgentConfigsType = {
  frontDeskAuthentication,
  customerServiceRetail,
  simpleExample,
  optimoLoanAgent: hinglishLoanAgent, // Change this line
};

export const defaultAgentSetKey = "optimoLoanAgent"; // And this one