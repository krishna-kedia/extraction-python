import sys
import os
import re  # For the summary to pretty print keys
import webbrowser
import tempfile
import threading
import time
import json
from http.server import HTTPServer, BaseHTTPRequestHandler
import urllib.parse

# --- Start of cli.py helper functions ---
# (Adapted from the provided cli.py reference)

output_buffer = []
# Determine if running in API mode (though for this script, it mostly behaves as CLI)
is_api_mode = "--api-mode" in sys.argv


def clear_screen():
    """Clears the terminal screen."""
    os.system('cls' if os.name == 'nt' else 'clear')

def print_buffered(message="", end="\n", message_type="text"):
    """
    Replace standard print with buffered version
    
    Args:
        message: The message to output
        end: End character (like in print)
        message_type: Type of message (text, error, status)
    """
    if is_api_mode:
        # Convert objects to strings if needed
        if not isinstance(message, str):
            message = str(message)

        # Handle different message types
        if message_type == "error":
            # For errors in API mode, add to buffer and flush immediately
            output_buffer.append(f"<STATUS:ERROR message=\"{message}\">")
            # Force immediate flush for errors
            flush_output()
        elif message_type == "status":
            output_buffer.append(f"<STATUS:{message}>")
        else:
            # For text that ends with newline, add as separate entry
            if end == "\n":
                output_buffer.append(message)
            # For text without newline, append to last entry or create new one
            else:
                if output_buffer:
                    output_buffer[-1] += message + end
                else:
                    output_buffer.append(message + end)
    else:
        # Normal mode: print directly
        if message_type == "error":
            print(f"\033[91mError: {message}\033[0m", end=end, flush=True)
        else:
            print(message, end=end, flush=True)


def flush_output(prompt="", input_type="text", options=None):
    """
    Send all buffered output and signal input request
    
    Args:
        prompt: Text prompt for input
        input_type: Type of input expected (text, option, confirmation)
        options: For option type, available choices
    """
    if is_api_mode and output_buffer:
        # Add termination marker
        output_buffer.append("<OUTPUT_COMPLETE>")

        # Add input request with metadata
        if options:
            options_str = ",".join(map(str, options))
            output_buffer.append(
                f"<INPUT_REQUEST type=\"{input_type}\" prompt=\"{prompt}\" options=\"{options_str}\">")
        else:
            output_buffer.append(
                f"<INPUT_REQUEST type=\"{input_type}\" prompt=\"{prompt}\">")

        # Print everything at once
        print("\n".join(output_buffer))
        output_buffer.clear()

        # Ensure output is sent immediately
        sys.stdout.flush()


def buffered_input(prompt="", input_type="text", options=None):
    """
    Replace standard input with a version that automatically flushes output
    """
    # First ensure any pending output is displayed
    if prompt:
        print_buffered(prompt, end="")

    # Handle buffer flushing internally
    if is_api_mode and output_buffer:
        output_buffer.append("<OUTPUT_COMPLETE>")

        if options:
            options_str = ",".join(map(str, options))
            output_buffer.append(
                f"<INPUT_REQUEST type=\"{input_type}\" prompt=\"{prompt}\" options=\"{options_str}\">")
        else:
            output_buffer.append(
                f"<INPUT_REQUEST type=\"{input_type}\" prompt=\"{prompt}\">")

        print("\n".join(output_buffer))
        output_buffer.clear()

        sys.stdout.flush()

    # Get the actual input
    try:
        user_input = input()
        return user_input
    except EOFError:
        # Handle case where there's no more input
        return ""
# --- End of cli.py helper functions ---


class FormHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == '/':
            self.send_response(200)
            self.send_header('Content-type', 'text/html')
            self.end_headers()
            self.wfile.write(self.server.html_content.encode('utf-8'))
        elif self.path == '/data':
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            response_data = {
                'formData': self.server.form_data,
                'currentField': self.server.current_field,
                'isCompleted': self.server.is_completed,
                'currentQuestion': self.server.current_question
            }
            self.wfile.write(json.dumps(response_data).encode('utf-8'))
        else:
            self.send_response(404)
            self.end_headers()

    def do_POST(self):
        if self.path == '/submit':
            content_length = int(self.headers['Content-Length'])
            post_data = self.rfile.read(content_length)
            form_data = urllib.parse.parse_qs(post_data.decode('utf-8'))

            # Process the submitted form data
            processed_data = {}
            for key, value in form_data.items():
                processed_data[key] = value[0] if value else ''

            self.server.final_form_data = processed_data

            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps(
                {'status': 'success', 'message': 'Form submitted successfully!'}).encode('utf-8'))
        else:
            self.send_response(404)
            self.end_headers()

    def log_message(self, format, *args):
        # Suppress server logs
        pass


class LoanApplicationCLI:
    def __init__(self):
        self.data = {}
        self.server = None
        self.server_thread = None
        self.port = 8000
        self.current_field = None
        self.current_question = ""
        self.is_completed = False
        self.options_map = {
            "loanType_options": ["Personal Loan", "Loan Against Property", "Home Loan", "Business Loan"],
            "incomeSource_options": ["Salary", "Business", "Business+Salary"],
            "yes_no_options": ["Yes", "No"],
            "propertyType_options": ["Residential", "Commercial", "Industrial", "Agriculture", "Open Land", "Under Construction"],
            "propertyStructure_options": ["Self-Owned Land & Building", "Flat", "Shop", "Office", "Vacant Land", "Plot"],
            "propertyUsage_options": ["Self-Occupied", "Rented", "Mixed Use", "Unoccupied"]
        }

        # Define questions in the exact order specified
        self.question_definitions = [
            # 1. Basic Personal Information
            {"id": "fullName", "question": "First of all, what is your full name?",
                "required": True, "section": "basic"},
            {"id": "address", "question": "Where do you live? Please provide detailed address",
                "required": True, "section": "basic"},

            # 2. Loan Requirements
            {"id": "loanType", "question": "What type of loan do you want to take?",
                "required": True, "options_key": "loanType_options", "section": "loan"},
            {"id": "loanAmount",
                "question": "How much loan do you need? (Rs.)", "required": True, "type": "number_positive", "section": "loan"},
            {"id": "emiComfort",
                "question": "How much EMI can you pay every month? (Rs.)", "required": True, "type": "number_positive", "section": "loan"},
            {"id": "monthlyObligations",
                "question": "What are your current monthly obligations? (Existing EMI, rent/home loan installment, and other non-formal payments) (Rs.)", "required": True, "type": "number_non_negative", "section": "loan"},

            # 3. Income Source Classification
            {"id": "incomeSource", "question": "What is your income source?",
                "required": True, "options_key": "incomeSource_options", "section": "income"},

            # Salary-specific questions
            {"id": "salaryAmount", "question": "What is your monthly salary? (Gross) (Rs.)", "required": True, "type": "number_positive",
             "condition": lambda: self.data.get("incomeSource") in ["Salary", "Business+Salary"], "section": "income"},
            {"id": "designationEmployer", "question": "What is your designation and employer's name?", "required": True,
             "condition": lambda: self.data.get("incomeSource") in ["Salary", "Business+Salary"], "section": "income"},
            {"id": "otherIncomeSources", "question": "Do you have any other income sources? If yes, please specify (rent, side business)", "required": False,
             "condition": lambda: self.data.get("incomeSource") in ["Salary", "Business+Salary"], "section": "income"},

            # Business-specific questions
            {"id": "businessRevenue", "question": "What is your average monthly total revenue? (Rs.)", "required": True, "type": "number_non_negative",
             "condition": lambda: self.data.get("incomeSource") in ["Business", "Business+Salary"], "section": "income"},
            {"id": "businessProfit", "question": "What is your average monthly net profit? (Rs.)", "required": True, "type": "number_any",
             "condition": lambda: self.data.get("incomeSource") in ["Business", "Business+Salary"], "section": "income"},
            {"id": "businessSalary", "question": "Do you take a separate salary from your business? If yes, how much? (Rs. - If no, enter 0)", "required": True, "type": "number_non_negative",
             "condition": lambda: self.data.get("incomeSource") in ["Business", "Business+Salary"], "section": "income"},

            # 4. Property Details (Collateral)
            {"id": "atPropertyLocation", "question": "Are you currently present at the collateral property location?",
                "required": True, "options_key": "yes_no_options", "section": "property"},
            {"id": "propertyAddress", "question": "What is the complete address of the collateral property?",
                "required": True, "section": "property"},
            {"id": "propertyType", "question": "What type of property is it?",
                "required": True, "options_key": "propertyType_options", "section": "property"},
            {"id": "propertyStructure", "question": "What is the structure of the property?",
                "required": True, "options_key": "propertyStructure_options", "section": "property"},
            {"id": "propertyUsage", "question": "How is the property currently being used?",
                "required": True, "options_key": "propertyUsage_options", "section": "property"},
            {"id": "landArea",
                "question": "What is the total land area of the property? (sq.ft. or sq.yards)", "required": True, "section": "property"},
            {"id": "marketValue",
                "question": "What is the estimated market value of the property? (Rs.)", "required": True, "type": "number_positive", "section": "property"},
            {"id": "existingLoan", "question": "Is there any existing loan on the property?",
                "required": True, "options_key": "yes_no_options", "section": "property"},

            # Conditional Property Question
            {"id": "existingLoanEmi", "question": "What is the current monthly EMI? (Rs.)", "required": True, "type": "number_positive",
             "condition": lambda: self.data.get("existingLoan") == "Yes", "section": "property"}
        ]

    def start_form_server(self):
        """Start the HTTP server to serve the form"""
        try:
            # Find an available port
            for port in range(8000, 8010):
                try:
                    self.port = port
                    self.server = HTTPServer(('localhost', port), FormHandler)
                    self.server.html_content = self.generate_live_html_form()
                    self.server.form_data = self.data
                    self.server.current_field = self.current_field
                    self.server.is_completed = self.is_completed
                    self.server.current_question = self.current_question
                    self.server.final_form_data = {}
                    break
                except OSError:
                    continue

            if self.server:
                self.server_thread = threading.Thread(
                    target=self.server.serve_forever)
                self.server_thread.daemon = True
                self.server_thread.start()
                return f"http://localhost:{self.port}"
            return None
        except Exception as e:
            print_buffered(f"Could not start form server: {e}")
            return None

    def update_form_data(self, field_id, value, question_text=""):
        """Update the form data and notify the browser"""
        self.current_field = field_id
        self.current_question = question_text
        self.data[field_id] = value
        if self.server:
            self.server.form_data = self.data.copy()
            self.server.current_field = self.current_field
            self.server.current_question = self.current_question
            self.server.is_completed = self.is_completed

    def mark_form_completed(self):
        """Mark the form as completed and allow editing"""
        self.is_completed = True
        self.current_field = None
        self.current_question = "Form completed! You can now review and edit if needed."
        if self.server:
            self.server.is_completed = self.is_completed
            self.server.current_field = self.current_field
            self.server.current_question = self.current_question

    def generate_live_html_form(self):
        """Generate an HTML form that updates in real-time"""

        # Helper function to create select options
        def create_select_options(options_list, field_id):
            options_html = '<option value="">Select an option...</option>\n'
            for option in options_list:
                options_html += f'<option value="{option}">{option}</option>\n'
            return options_html

        html_content = f"""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Loan Application Form - AI Assistant</title>
    <style>
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}
        
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 20px;
            min-height: 100vh;
        }}
        
        .container {{
            max-width: 900px;
            margin: 0 auto;
            background: white;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            overflow: hidden;
        }}
        
        .header {{
            background: linear-gradient(135deg, #007bff, #0056b3);
            color: white;
            text-align: center;
            padding: 30px;
        }}
        
        .header h1 {{
            margin-bottom: 10px;
            font-size: 2.2em;
        }}
        
        .ai-status {{
            background: linear-gradient(135deg, #28a745, #20c997);
            color: white;
            padding: 15px;
            text-align: center;
            font-weight: 600;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }}
        
        .ai-status.completed {{
            background: linear-gradient(135deg, #6f42c1, #6610f2);
        }}
        
        .ai-status .typing-indicator {{
            display: flex;
            gap: 3px;
        }}
        
        .ai-status .typing-indicator span {{
            width: 8px;
            height: 8px;
            border-radius: 50%;
            background-color: white;
            animation: typing 1.4s infinite ease-in-out;
        }}
        
        .ai-status .typing-indicator span:nth-child(1) {{ animation-delay: 0s; }}
        .ai-status .typing-indicator span:nth-child(2) {{ animation-delay: 0.2s; }}
        .ai-status .typing-indicator span:nth-child(3) {{ animation-delay: 0.4s; }}
        
        @keyframes typing {{
            0%, 60%, 100% {{ transform: scale(1); opacity: 0.7; }}
            30% {{ transform: scale(1.3); opacity: 1; }}
        }}
        
        .form-container {{
            padding: 30px;
            max-height: 70vh;
            overflow-y: auto;
            scroll-behavior: smooth;
        }}
        
        .section {{
            margin-bottom: 40px;
            padding: 25px;
            background-color: #f8f9fa;
            border-radius: 12px;
            border-left: 5px solid #007bff;
            transform: translateX(-100%);
            opacity: 0;
            transition: all 0.8s cubic-bezier(0.4, 0, 0.2, 1);
        }}
        
        .section.active {{
            transform: translateX(0);
            opacity: 1;
        }}
        
        .section.completed {{
            border-left-color: #28a745;
            background-color: #f8fff8;
        }}
        
        .section h2 {{
            color: #007bff;
            margin-bottom: 25px;
            font-size: 1.4em;
            display: flex;
            align-items: center;
            gap: 10px;
        }}
        
        .section.completed h2 {{
            color: #28a745;
        }}
        
        .section-icon {{
            width: 24px;
            height: 24px;
            border-radius: 50%;
            background-color: #007bff;
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 14px;
            font-weight: bold;
        }}
        
        .section.completed .section-icon {{
            background-color: #28a745;
        }}
        
        .form-group {{
            margin-bottom: 25px;
            transform: translateY(20px);
            opacity: 0;
            transition: all 0.6s ease;
        }}
        
        .form-group.filled {{
            transform: translateY(0);
            opacity: 1;
        }}
        
        .form-group label {{
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #555;
            font-size: 1.1em;
        }}
        
        .form-group input,
        .form-group select,
        .form-group textarea {{
            width: 100%;
            padding: 15px;
            border: 2px solid #ddd;
            border-radius: 8px;
            font-size: 16px;
            transition: all 0.3s ease;
            background-color: #f8f9fa;
        }}
        
        .form-group input.filled,
        .form-group select.filled,
        .form-group textarea.filled {{
            background-color: #e8f5e8;
            border-color: #28a745;
            color: #155724;
            font-weight: 500;
        }}
        
        .form-group input.current,
        .form-group select.current,
        .form-group textarea.current {{
            background-color: #fff3cd;
            border-color: #ffc107;
            animation: pulse 2s infinite;
            box-shadow: 0 0 0 3px rgba(255, 193, 7, 0.2);
        }}
        
        .form-group input.editable,
        .form-group select.editable,
        .form-group textarea.editable {{
            background-color: white;
            border-color: #007bff;
            cursor: text;
        }}
        
        .form-group input.editable:focus,
        .form-group select.editable:focus,
        .form-group textarea.editable:focus {{
            outline: none;
            border-color: #0056b3;
            box-shadow: 0 0 0 3px rgba(0, 123, 255, 0.2);
        }}
        
        @keyframes pulse {{
            0% {{ box-shadow: 0 0 0 0 rgba(255, 193, 7, 0.7); }}
            70% {{ box-shadow: 0 0 0 10px rgba(255, 193, 7, 0); }}
            100% {{ box-shadow: 0 0 0 0 rgba(255, 193, 7, 0); }}
        }}
        
        .form-group textarea {{
            height: 100px;
            resize: vertical;
        }}
        
        .required {{
            color: #dc3545;
        }}
        
        .form-row {{
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 25px;
        }}
        
        .hidden {{
            display: none;
        }}
        
        .progress-bar {{
            width: 100%;
            height: 8px;
            background-color: #e9ecef;
            border-radius: 4px;
            overflow: hidden;
            margin: 20px 0;
        }}
        
        .progress-fill {{
            height: 100%;
            background: linear-gradient(90deg, #007bff, #28a745);
            transition: width 1s ease;
            border-radius: 4px;
        }}
        
        .submit-section {{
            padding: 30px;
            background-color: #f8f9fa;
            text-align: center;
            border-top: 1px solid #dee2e6;
        }}
        
        .btn {{
            padding: 15px 40px;
            margin: 0 10px;
            border: none;
            border-radius: 8px;
            font-size: 18px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            text-transform: uppercase;
            letter-spacing: 1px;
        }}
        
        .btn-primary {{
            background: linear-gradient(135deg, #007bff, #0056b3);
            color: white;
        }}
        
        .btn-primary:hover {{
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 123, 255, 0.3);
        }}
        
        .btn-secondary {{
            background: linear-gradient(135deg, #6c757d, #545b62);
            color: white;
        }}
        
        .btn-secondary:hover {{
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(108, 117, 125, 0.3);
        }}
        
        .completion-message {{
            background: linear-gradient(135deg, #28a745, #20c997);
            color: white;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            text-align: center;
            font-size: 1.2em;
            font-weight: 600;
        }}
        
        @media (max-width: 768px) {{
            .form-row {{
                grid-template-columns: 1fr;
            }}
            
            .container {{
                margin: 10px;
                border-radius: 10px;
            }}
            
            .form-container {{
                padding: 20px;
            }}
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🤖 AI Loan Assistant</h1>
            <p>I'm filling out your loan application form in real-time</p>
        </div>
        
        <div class="ai-status" id="aiStatus">
            <span id="statusText">🤖 AI is preparing to fill your form...</span>
            <div class="typing-indicator" id="typingIndicator">
                <span></span>
                <span></span>
                <span></span>
            </div>
        </div>
        
        <div class="progress-bar">
            <div class="progress-fill" id="progressFill" style="width: 0%"></div>
        </div>
        
        <div class="form-container" id="formContainer">
            <form id="loanForm">
                <!-- Basic Personal Information -->
                <div class="section" id="section-basic" data-section="basic">
                    <h2><span class="section-icon">1</span>Basic Personal Information</h2>
                    <div class="form-group">
                        <label for="fullName">Full Name <span class="required">*</span></label>
                        <input type="text" id="fullName" name="fullName">
                    </div>
                    <div class="form-group">
                        <label for="address">Address <span class="required">*</span></label>
                        <textarea id="address" name="address"></textarea>
                    </div>
                </div>
                
                <!-- Loan Requirements -->
                <div class="section" id="section-loan" data-section="loan">
                    <h2><span class="section-icon">2</span>Loan Requirements</h2>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="loanType">Loan Type <span class="required">*</span></label>
                            <select id="loanType" name="loanType">
                                {create_select_options(self.options_map['loanType_options'], 'loanType')}
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="loanAmount">Loan Amount (Rs.) <span class="required">*</span></label>
                            <input type="number" id="loanAmount" name="loanAmount">
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="emiComfort">EMI Comfort (Rs.) <span class="required">*</span></label>
                            <input type="number" id="emiComfort" name="emiComfort">
                        </div>
                        <div class="form-group">
                            <label for="monthlyObligations">Monthly Obligations (Rs.) <span class="required">*</span></label>
                            <input type="number" id="monthlyObligations" name="monthlyObligations">
                        </div>
                    </div>
                </div>
                
                <!-- Income Information -->
                <div class="section" id="section-income" data-section="income">
                    <h2><span class="section-icon">3</span>Income Information</h2>
                    <div class="form-group">
                        <label for="incomeSource">Income Source <span class="required">*</span></label>
                        <select id="incomeSource" name="incomeSource">
                            {create_select_options(self.options_map['incomeSource_options'], 'incomeSource')}
                        </select>
                    </div>
                    
                    <!-- Salary Fields -->
                    <div id="salaryFields">
                        <div class="form-row">
                            <div class="form-group">
                                <label for="salaryAmount">Monthly Salary (Rs.)</label>
                                <input type="number" id="salaryAmount" name="salaryAmount">
                            </div>
                            <div class="form-group">
                                <label for="designationEmployer">Designation & Employer</label>
                                <input type="text" id="designationEmployer" name="designationEmployer">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="otherIncomeSources">Other Income Sources</label>
                            <input type="text" id="otherIncomeSources" name="otherIncomeSources">
                        </div>
                    </div>
                    
                    <!-- Business Fields -->
                    <div id="businessFields">
                        <div class="form-row">
                            <div class="form-group">
                                <label for="businessRevenue">Monthly Revenue (Rs.)</label>
                                <input type="number" id="businessRevenue" name="businessRevenue">
                            </div>
                            <div class="form-group">
                                <label for="businessProfit">Monthly Profit (Rs.)</label>
                                <input type="number" id="businessProfit" name="businessProfit">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="businessSalary">Business Salary (Rs.)</label>
                            <input type="number" id="businessSalary" name="businessSalary">
                        </div>
                    </div>
                </div>
                
                <!-- Property Details -->
                <div class="section" id="section-property" data-section="property">
                    <h2><span class="section-icon">4</span>Property Details (Collateral)</h2>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="atPropertyLocation">At Property Location <span class="required">*</span></label>
                            <select id="atPropertyLocation" name="atPropertyLocation">
                                {create_select_options(self.options_map['yes_no_options'], 'atPropertyLocation')}
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="propertyType">Property Type <span class="required">*</span></label>
                            <select id="propertyType" name="propertyType">
                                {create_select_options(self.options_map['propertyType_options'], 'propertyType')}
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="propertyAddress">Property Address <span class="required">*</span></label>
                        <textarea id="propertyAddress" name="propertyAddress"></textarea>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="propertyStructure">Property Structure <span class="required">*</span></label>
                            <select id="propertyStructure" name="propertyStructure">
                                {create_select_options(self.options_map['propertyStructure_options'], 'propertyStructure')}
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="propertyUsage">Property Usage <span class="required">*</span></label>
                            <select id="propertyUsage" name="propertyUsage">
                                {create_select_options(self.options_map['propertyUsage_options'], 'propertyUsage')}
                            </select>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="landArea">Land Area <span class="required">*</span></label>
                            <input type="text" id="landArea" name="landArea">
                        </div>
                        <div class="form-group">
                            <label for="marketValue">Market Value (Rs.) <span class="required">*</span></label>
                            <input type="number" id="marketValue" name="marketValue">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="existingLoan">Existing Loan <span class="required">*</span></label>
                        <select id="existingLoan" name="existingLoan">
                            {create_select_options(self.options_map['yes_no_options'], 'existingLoan')}
                        </select>
                    </div>
                    <div id="emiField" class="form-group">
                        <label for="existingLoanEmi">Existing Loan EMI (Rs.)</label>
                        <input type="number" id="existingLoanEmi" name="existingLoanEmi">
                    </div>
                </div>
            </form>
        </div>
        
        <div class="submit-section" id="submitSection" style="display: none;">
            <div class="completion-message">
                🎉 Form completed successfully! You can now review and edit any information before submitting.
            </div>
            <button type="button" class="btn btn-primary" onclick="submitForm()">Submit Application</button>
            <button type="button" class="btn btn-secondary" onclick="printForm
<button type="button" class="btn btn-secondary" onclick="printForm()">Print Form</button>
       </div>
   </div>

   <script>
       let totalFields = 0;
       let filledFields = 0;
       let currentSection = null;
       let isFormCompleted = false;
       let typingTimer = null;
       let updateInterval = null;
       const sectionOrder = ['basic', 'loan', 'income', 'property'];

       function updateForm() {{
           fetch('/data')
               .then(response => response.json())
               .then(data => {{
                   const formData = data.formData;
                   const currentField = data.currentField;
                   const isCompleted = data.isCompleted;
                   const currentQuestion = data.currentQuestion;

                   filledFields = 0;

                   // Update status
                   updateAIStatus(currentQuestion, isCompleted, currentField);

                   // Update all form fields
                   for (const [key, value] of Object.entries(formData)) {{
                       const element = document.getElementById(key);
                       if (element && value !== null && value !== '' && value !== undefined) {{
                           // Simulate typing effect for current field
                           if (key === currentField && !isCompleted) {{
                               simulateTyping(element, value);
                           }} else {{
                               element.value = value;
                               markFieldFilled(element);
                           }}
                           filledFields++;
                       }}
                   }}

                   // Update current field highlighting
                   updateCurrentField(currentField, isCompleted);

                   // Update sections
                   updateSections(currentField, formData);

                   // Update progress bar
                   const progress = totalFields > 0 ? (filledFields / totalFields) * 100 : 0;
                   document.getElementById(
                       'progressFill').style.width = progress + '%';

                   // Show/hide conditional fields
                   updateConditionalFields(formData);

                   // Handle form completion
                   if (isCompleted && !isFormCompleted) {{
                       handleFormCompletion();
                       isFormCompleted = true;
                   }}
               }})
               .catch(error => {{
                   console.error('Error updating form:', error);
               }});
       }}

       function updateAIStatus(currentQuestion, isCompleted, currentField) {{
           const statusElement = document.getElementById('statusText');
           const statusContainer = document.getElementById('aiStatus');
           const typingIndicator = document.getElementById('typingIndicator');

           if (isCompleted) {{
               statusContainer.className = 'ai-status completed';
               statusElement.textContent = '✅ ' + currentQuestion;
               typingIndicator.style.display = 'none';
           }} else if (currentField) {{
               statusContainer.className = 'ai-status';
               statusElement.textContent = '🤖 AI is filling: ' + currentQuestion;
               typingIndicator.style.display = 'flex';
           }} else {{
               statusContainer.className = 'ai-status';
               statusElement.textContent = '🤖 AI is preparing...';
               typingIndicator.style.display = 'flex';
           }}
       }}

       function simulateTyping(element, finalValue) {{
           if (element.dataset.isTyping === 'true') return; // Prevent multiple typing animations

           element.dataset.isTyping = 'true';
           element.classList.add('current');

           const chars = finalValue.toString().split('');
           let currentText = '';
           let index = 0;

           const typeChar = () => {{
               if (index < chars.length) {{
                   currentText += chars[index];
                   element.value = currentText;
                   index++;
                   setTimeout(typeChar, 50 + Math.random() * 100); // Random typing speed
               }} else {{
                   // Typing complete
                   element.dataset.isTyping = 'false';
                   element.classList.remove('current');
                   markFieldFilled(element);
               }}
           }};

           typeChar();
       }}

       function markFieldFilled(element) {{
           element.classList.add('filled');
           const formGroup = element.closest('.form-group');
           if (formGroup) {{
               formGroup.classList.add('filled');
           }}
       }}

       function updateCurrentField(currentField, isCompleted) {{
           // Remove current highlighting from all fields
           document.querySelectorAll('.current').forEach(el => {{
               if (el.dataset.isTyping !== 'true') {{
                   el.classList.remove('current');
               }}
           }});

           if (!isCompleted && currentField) {{
               const element = document.getElementById(currentField);
               if (element && element.dataset.isTyping !== 'true') {{
                   element.classList.add('current');
                   // Smooth scroll to current field
                   element.scrollIntoView({{
                       behavior: 'smooth',
                       block: 'center',
                       inline: 'nearest'
                   }});
               }}
           }}
       }}

       function updateSections(currentField, formData) {{
           const sections = document.querySelectorAll('.section');

           // Find current section based on current field
           let activeSection = null;
           if (currentField) {{
               const fieldElement = document.getElementById(currentField);
               if (fieldElement) {{
                   activeSection = fieldElement.closest('.section');
               }}
           }}

           sections.forEach(section => {{
               const sectionName = section.dataset.section;
               const hasFilledFields = Array.from(section.querySelectorAll('input, select, textarea'))
                   .some(field => formData[field.id] && formData[field.id] !== '');

               if (hasFilledFields || section === activeSection) {{
                   section.classList.add('active');
               }}

               // Mark section as completed if all required fields are filled
               const requiredFields = Array.from(section.querySelectorAll('input[required], select[required], textarea[required]'));
               const allRequiredFilled = requiredFields.every(field =>
                   formData[field.id] && formData[field.id] !== ''
               );

               if (allRequiredFilled && requiredFields.length > 0) {{
                   section.classList.add('completed');
               }}
           }});
       }}

       function updateConditionalFields(formData) {{
           const incomeSource = formData.incomeSource;
           const salaryFields = document.getElementById('salaryFields');
           const businessFields = document.getElementById('businessFields');

           if (incomeSource === 'Salary' || incomeSource === 'Business+Salary') {{
               salaryFields.style.display = 'block';
           }} else {{
               salaryFields.style.display = 'none';
           }}

           if (incomeSource === 'Business' || incomeSource === 'Business+Salary') {{
               businessFields.style.display = 'block';
           }} else {{
               businessFields.style.display = 'none';
           }}

           // Show/hide EMI field
           const existingLoan = formData.existingLoan;
           const emiField = document.getElementById('emiField');
           if (existingLoan === 'Yes') {{
               emiField.style.display = 'block';
           }} else {{
               emiField.style.display = 'none';
           }}
       }}

       function handleFormCompletion() {{
           clearInterval(updateInterval); // Stop polling when form is completed
           // Enable editing for all fields
           const allFields = document.querySelectorAll('input, select, textarea');
           allFields.forEach(field => {{
               field.readOnly = false;
               field.disabled = false;
               field.classList.add('editable');
               field.classList.remove('current');
           }});

           // Show submit section
           document.getElementById('submitSection').style.display = 'block';

           // Add completed class to all sections
           document.querySelectorAll('.section').forEach(section => {{
               section.classList.add('completed');
           }});

           // Scroll to submit section
           document.getElementById('submitSection').scrollIntoView({{
               behavior: 'smooth'
           }});
       }}

       function submitForm() {{
           const form = document.getElementById('loanForm');
           const formData = new FormData(form);

           // Convert FormData to regular object for validation
           const data = {{}};
           for (let [key, value] of formData.entries()) {{
               data[key] = value;
           }}

           // Basic validation
           const requiredFields = form.querySelectorAll('[required]');
           let isValid = true;

           requiredFields.forEach(field => {{
               if (!field.value.trim()) {{
                   field.style.borderColor = '#dc3545';
                   isValid = false;
               }} else {{
                   field.style.borderColor = '#28a745';
               }}
           }});

           if (isValid) {{
               // Submit form data
               fetch('/submit', {{
                   method: 'POST',
                   body: new URLSearchParams(data)
               }})
               .then(response => response.json())
               .then(result => {{
                   if (result.status === 'success') {{
                       alert(
                           '🎉 Application submitted successfully!\\n\\nThank you for your application. You will receive a response within 2-3 business days.');
                   }} else {{
                       alert('❌ Error submitting application. Please try again.');
                   }}
               }})
               .catch(error => {{
                   console.error('Error submitting form:', error);
                   alert('❌ Error submitting application. Please try again.');
               }});
           }} else {{
               alert('⚠️ Please fill in all required fields before submitting.');
           }}
       }}

       function printForm() {{
           // Hide submit section for printing
           document.getElementById('submitSection').style.display = 'none';
           document.getElementById('aiStatus').style.display = 'none';

           window.print();

           // Restore submit section after printing
           setTimeout(() => {{
               document.getElementById(
                   'submitSection').style.display = 'block';
               document.getElementById('aiStatus').style.display = 'flex';
           }}, 1000);
       }}
        // Initialize
        document.addEventListener('DOMContentLoaded', function() {{
            // Count total fields for progress calculation
            totalFields = document.querySelectorAll('input[required], select[required], textarea[required]').length;

            // Make all fields read-only initially
            const allFields = document.querySelectorAll('input, select, textarea');
            allFields.forEach(field => {{
                field.readOnly = true;
                field.disabled = true;
            }});

            // Start updating form data
            updateInterval = setInterval(updateForm, 300);

            updateForm();
        }});
   </script>
</body>
</html>
       """

        return html_content

    def _ask_single_question(self, q_def):
        question_id = q_def["id"]
        question_text = q_def["question"]
        required = q_def["required"]
        options_key = q_def.get("options_key")
        q_type = q_def.get("type")  # For number validation

        if q_def.get("condition") and not q_def["condition"]():
            self.update_form_data(question_id, None, "")
            return None  # Skip this question

        # Update current field being asked
        self.update_form_data(question_id, "", question_text)

        prompt_display_text = f"\n{question_text}"
        if required:
            prompt_display_text += " (Required)"

        current_options_list = None
        if options_key and options_key in self.options_map:
            current_options_list = self.options_map[options_key]
            prompt_display_text += "\n"
            for i, opt in enumerate(current_options_list):
                prompt_display_text += f"{i+1}. {opt}\n"
            prompt_display_text += "Enter your choice number: "
        else:
            prompt_display_text += ": "

        while True:
            print_buffered(prompt_display_text, end="")
            user_input = buffered_input().strip()

            if not user_input:
                if required:
                    print_buffered("This information is required. Please enter it.")
                    continue
                else:
                    # Store empty for non-required skipped
                    self.update_form_data(question_id, "", question_text)
                    return ""

            if current_options_list:
                try:
                    choice_idx = int(user_input) - 1
                    if 0 <= choice_idx < len(current_options_list):
                        selected_value = current_options_list[choice_idx]
                        self.update_form_data(question_id, selected_value, question_text)
                        print_buffered(f"✓ Selected: {selected_value}")
                        time.sleep(1)  # Give time for typing animation
                        return selected_value
                    else:
                        print_buffered(f"Invalid choice. Please select a number between 1 and {len(current_options_list)}.")
                except ValueError:
                    print_buffered("Invalid input. Please enter a valid number.")
            else:  # Free text input
                if q_type:
                    try:
                        # Try float to allow decimals
                        num_val = float(user_input)
                        if q_type == "number_positive" and num_val <= 0:
                            print_buffered("Please enter a number greater than 0.")
                            continue
                        if q_type == "number_non_negative" and num_val < 0:
                            print_buffered("Please enter a number greater than or equal to 0.")
                            continue
                        # For "number_any", any number is fine.
                        # Storing as string, can be converted later if needed
                    except ValueError:
                        print_buffered("Please enter a valid number.")
                        continue

                self.update_form_data(question_id, user_input, question_text)
                print_buffered(f"✓ Entered: {user_input}")
                time.sleep(1)  # Give time for typing animation
                return user_input

    def start_application(self):
        clear_screen()
        print_buffered("🤖 Hello! I am your AI loan assistant.")
        print_buffered("I will help you fill out your loan application form.")
        print_buffered("You can watch me fill the form in real-time in your browser!")
        print_buffered("\nWould you like to apply for a loan?")

        while True:
            print_buffered("1. Yes - Let's start!\n2. No - Maybe later")
            print_buffered("Enter your choice (1 or 2): ", end="")
            choice = buffered_input().strip()
            if choice == '1':
                return True
            elif choice == '2':
                print_buffered("No problem! We're here whenever you're ready. Thank you! 👋")
                return False
            else:
                print_buffered("Invalid choice. Please enter 1 or 2.")

    def collect_all_information(self):
        print_buffered("\n" + "="*60)
        print_buffered("🚀 STARTING LOAN APPLICATION PROCESS")
        print_buffered("="*60)
        
        print_buffered("📋 Setting up your personalized form...")
        
        # Start the form server
        form_url = self.start_form_server()
        if form_url:
            print_buffered(f"✅ Form server started successfully!")
            print_buffered(f"🌐 Opening form in browser: {form_url}")
            try:
                webbrowser.open(form_url)
                time.sleep(2)  # Give browser time to load
            except Exception as e:
                print_buffered(f"⚠️  Could not open browser automatically. Please open: {form_url}")
            
            print_buffered("\n" + "🔴"*20 + " IMPORTANT " + "🔴"*20)
            print_buffered("📱 KEEP YOUR BROWSER WINDOW OPEN!")
            print_buffered("👀 Watch as I fill out your form in real-time")
            print_buffered("🎯 Each answer you provide will appear instantly in the browser")
            print_buffered("✏️  You'll be able to edit everything once I'm done")
            print_buffered("🔴"*50)
            
            # Wait a moment for the browser to load
            print_buffered("\n⏳ Giving your browser a moment to load...")
            time.sleep(3)
        else:
            print_buffered("⚠️  Could not start form server. Continuing with CLI only.")
        
        print_buffered("\n🤖 Ready! Let's begin with your loan application...")
        print_buffered("💬 I'll ask you questions one by one, and you'll see the form fill up automatically!")
        
        for q_def in self.question_definitions:
            self._ask_single_question(q_def)

        # Mark form as completed
        self.mark_form_completed()
        print_buffered("\n🎉 Excellent! I've finished filling out your form!")

    def display_final_summary(self):
        clear_screen()
        print_buffered("🎉" + "="*50 + "🎉")
        print_buffered("    LOAN APPLICATION COMPLETED SUCCESSFULLY!")
        print_buffered("🎉" + "="*50 + "🎉")
        
        print_buffered("\n✅ What I've accomplished:")
        print_buffered("   📝 Collected all your information")
        print_buffered("   🖥️  Filled out your form in real-time")
        print_buffered("   ✏️  Enabled editing mode for your review")
        print_buffered("   🎯 Made everything ready for submission")
        
        if self.server:
            print_buffered(f"\n🌐 Your form is live at: http://localhost:{self.port}")
            print_buffered("\n🔧 What you can do now:")
            print_buffered("   👁️  Review all the information I filled")
            print_buffered("   ✏️  Edit any fields if needed")
            print_buffered("   📤 Submit your final application")
            print_buffered("   🖨️  Print the form for your records")
        
        print_buffered("\n📋 Next steps:")
        print_buffered("   1️⃣  Go to your browser and review the completed form")
        print_buffered("   2️⃣  Make any changes you need")
        print_buffered("   3️⃣  Click 'Submit Application' when ready")
        print_buffered("   4️⃣  Expect a response within 2-3 business days")
        
        print_buffered("\n🤔 Do you have any questions before we wrap up?")
        print_buffered("1. Yes - I need help")
        print_buffered("2. No - I'm all set!")
        print_buffered("Enter your choice (1 or 2): ", end="")
        choice = buffered_input().strip()
        
        if choice == '1':
            print_buffered("\n📞 Here's how to get help:")
            print_buffered("   💬 Chat: Available in the browser form")
            print_buffered("   📧 Email: support@loancompany.com")
            print_buffered("   📱 Phone: 1800-XXX-XXXX (24/7 support)")
            print_buffered("   🤝 Personal: A representative will call within 24 hours")
        else:
            print_buffered("\n🌟 Perfect! You're all set to go!")
        
        print_buffered("\n💫 Thank you for choosing our AI-powered loan service!")
        print_buffered("🚀 Your journey to financial freedom starts here!")
        
        # Keep server running
        if self.server:
            print_buffered(f"\n🔄 Your form will stay active for easy access.")
            print_buffered("💡 Press Ctrl+C when you're completely done.")
            
            try:
                # Keep the server running until user interrupts
                while True:
                    time.sleep(1)
            except KeyboardInterrupt:
                print_buffered("\n\n👋 Thank you for using our AI loan assistant!")
                print_buffered("🎯 Don't forget to submit your form in the browser!")
                print_buffered("🌟 Have a wonderful day!")
                self.cleanup_server()

    def cleanup_server(self):
        """Clean up the server resources"""
        if self.server:
            self.server.shutdown()
            self.server.server_close()
        if self.server_thread:
            self.server_thread.join(timeout=1)

    def run(self):
        try:
            if not self.start_application():
                return

            self.collect_all_information()
            self.display_final_summary()
        except KeyboardInterrupt:
            print_buffered("\n\n⚠️  Application interrupted by user.")
            self.cleanup_server()
            print_buffered("👋 Thank you for your time!")
        except Exception as e:
            print_buffered(f"\n❌ An error occurred: {e}")
            self.cleanup_server()
        finally:
            # Ensure cleanup
            self.cleanup_server()


if __name__ == "__main__":
   app = LoanApplicationCLI()
   app.run()